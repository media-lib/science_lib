<!--

function newImage(arg) {
	if (document.images) {
		rslt = new Image();
		rslt.src = arg;
		return rslt;
	}
}

function changeImages() {
	if (document.images && (preloadFlag == true)) {
		for (var i=0; i<changeImages.arguments.length; i+=2) {
			document[changeImages.arguments[i]].src = changeImages.arguments[i+1];
		}
	}
}

var preloadFlag = false;
function preloadImages() {
	if (document.images) {
		id1_over = newImage("images/1_over.gif");
		id2_over = newImage("images/2_over.gif");
		id3_over = newImage("images/3_over.gif");
		id4_over = newImage("images/4_over.gif");
		id5_over = newImage("images/5_over.gif");
		preloadFlag = true;
	}
}

// -->