<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<HTML>
<HEAD>
<TITLE></TITLE>

<META NAME="description" CONTENT="">

<META NAME="keywords" CONTENT="">

<META NAME="author" CONTENT="Raycon">

<BASE href="http://www.holoscience.com/">

<META NAME="MSSmartTagsPreventParsing" content="TRUE">

<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">

<link rel=stylesheet href="local.css" type="text/css">

<SCRIPT LANGUAGE="JavaScript" src="../template/mouseover.js"></SCRIPT>

</HEAD>

<BODY bgcolor="#000000" marginwidth="0" marginheight="0" leftmargin="0" topmargin="0" ONLOAD="self.focus();document.search.keywords.focus();preloadImages();">

<!-- Page header table -->
<TABLE WIDTH=1600 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD><img src="g/newsheader1.jpg" width=604 height=74 border=0 alt="The Electric Universe"></TD>
		<TD><img src="g/internalheader2.gif" width=1 height=74 border=0 alt="The Electric Universe"></TD>
		<TD><img src="g/internalheader3.gif" width=175 height=74 border=0 alt="The Electric Universe"></TD>
		<TD height=74 width=820 BGCOLOR=#000000></TD>
	</TR>
</TABLE>

<!-- Buttons and search bar table -->
<TABLE WIDTH=1600 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<!-- White line -->
		<TD colspan=11 HEIGHT=1 BGCOLOR=#ffffff></TD>
	</TR>
	<TR>
		<TD><img src="g/internalsearch1.gif" WIDTH=25 HEIGHT=27 border=0 alt="The Electric Universe">		</TD>

		<!-- Button template goes here -->
		<TD><A HREF="index.php" ONMOUSEOVER="changeImages('id0', 'gbi/0_over.gif'); return true;"
ONMOUSEOUT="changeImages('id0', 'gbi/0.gif'); return true;">
<IMG NAME="id0" SRC="gbi/0.gif" width="40" height="27" BORDER=0></A></TD>
<TD><A HREF="preface.php" ONMOUSEOVER="changeImages('id1', 'gbi/1_over.gif'); return true;"
ONMOUSEOUT="changeImages('id1', 'gbi/1.gif'); return true;">
<IMG NAME="id1" SRC="gbi/1.gif" width="45" height="27" BORDER=0></A></TD>
<TD><A HREF="news.php" ONMOUSEOVER="changeImages('id2', 'gbi/2_over.gif'); return true;"
ONMOUSEOUT="changeImages('id2', 'gbi/2_over.gif'); return true;">
<IMG NAME="id2" SRC="gbi/2_over.gif" width="80" height="27" BORDER=0></A></TD>
<TD><A HREF="synopsis.php" ONMOUSEOVER="changeImages('id3', 'gbi/3_over.gif'); return true;"
ONMOUSEOUT="changeImages('id3', 'gbi/3.gif'); return true;">
<IMG NAME="id3" SRC="gbi/3.gif" width="60" height="27" BORDER=0></A></TD>
<TD><A HREF="links.php" ONMOUSEOVER="changeImages('id4', 'gbi/4_over.gif'); return true;"
ONMOUSEOUT="changeImages('id4', 'gbi/4.gif'); return true;">
<IMG NAME="id4" SRC="gbi/4.gif" width="40" height="27" BORDER=0></A></TD>
<TD><A HREF="contact.php" ONMOUSEOVER="changeImages('id5', 'gbi/5_over.gif'); return true;"
ONMOUSEOUT="changeImages('id5', 'gbi/5.gif'); return true;">
<IMG NAME="id5" SRC="gbi/5.gif" width="50" height="27" BORDER=0></A></TD>

		<TD><img src="g/internalsearch2.gif" WIDTH=262 HEIGHT=27 border=0 alt="The Electric Universe">		</TD>

		<TD WIDTH=139 HEIGHT=27>
		<!-- Search box table -->

		<TABLE WIDTH=139 BORDER=0 CELLPADDING=0 CELLSPACING=0>
<form name="search" method="post" action="search.php">
		<tr>
			<TD WIDTH=139 HEIGHT=19 valign="middle">
				
				<input type="text" name="keywords" size="22" style="width:139px;height:20px;background-color:#000000;" class="stextw" value="">
			</TD>
		</tr>
		</table>

		</TD>

		<TD><input type="image" src="g/internalsearch3.gif" WIDTH=39 HEIGHT=27 border="0" alt="The Electric Universe">		</TD>
		<TD height=27 width=820 BGCOLOR=#000000></TD>

	</TR>

	<TR>
		<!-- White line -->
		<TD colspan=11 HEIGHT=1 BGCOLOR=#ffffff></TD>
	</TR>


</form>
</TABLE>

<TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0><TD colspan=2 HEIGHT=34></TD></TR><TR><TD WIDTH=126 HEIGHT=10></TD><TD><img src="g/newstitle.gif" width="85" height="11" border=0></TD></TR><TR><TD colspan=2 HEIGHT=20></TD></TR></TABLE><TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0><TR><TD WIDTH=126></TD><TD>01 March  2010<a name="top"><br><a class="news" href="news.php?article=ah63dzac">Our Misunderstood Sun</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>23 December  2009<a name="top"><br><a class="news" href="news.php?article=8pjd9xpp">Science, Politics and Global Warming</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>20 October  2009<a name="top"><br><a class="news" href="news.php?article=74fgmwne">Electric Sun Verified</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>06 September  2009<a name="top"><br><a class="news" href="news.php?article=wxse6f8q">The Simple Electric Universe</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>28 June  2009<a name="top"><br><a class="news" href="news.php?article=jdjcab6s">The Mystery of the Shrinking Red Star</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>24 May  2009<a name="top"><br><a class="news" href="news.php?article=ep8d37ws">Cosmology in Crisis�Again!</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>21 April  2009<a name="top"><br><a class="news" href="news.php?article=q1q6sz2s">Newton�s Electric Clockwork Solar System</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>28 March  2009<a name="top"><br><a class="news" href="news.php?article=7qqsr17q">The Black Hole at the Heart of Astronomy</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>15 February  2009<a name="top"><br><a class="news" href="news.php?article=6bcdajsb">It�s Time for Change</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>15 January  2009<a name="top"><br><a class="news" href="news.php?article=bqx15w21">Astronomy has little to celebrate in 2009!</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>22 December  2008<a name="top"><br><a class="news" href="news.php?article=b8zgwr0h">NASA�s Dim View of Stars</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>23 October  2008<a name="top"><br><a class="news" href="news.php?article=7y7d3dn5">Assembling the Solar System</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>10 September  2008<a name="top"><br><a class="news" href="news.php?article=gzhqr188">The $6 billion LHC Circus</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>22 August  2008<a name="top"><br><a class="news" href="news.php?article=89xdcmfs">Electric Gravity in an Electric Universe</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>01 July  2008<a name="top"><br><a class="news" href="news.php?article=x49g6gsf">Twinkle, twinkle electric star</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>20 May  2008<a name="top"><br><a class="news" href="news.php?article=2m1r5m3b">Electric Galaxies</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>13 May  2008<a name="top"><br><a class="news" href="news.php?article=a57ya4dj">Whatever happened to real science?</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>01 April  2008<a name="top"><br><a class="news" href="news.php?article=h103sydx">Enceladus, comets and electric moons</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>12 March  2008<a name="top"><br><a class="news" href="news.php?article=xcafwdgn">Enceladus' Cometary Plumes</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>05 March  2008<a name="top"><br><a class="news" href="news.php?article=8qysa3zk">More on Mercury�s Mysteries</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>25 January  2008<a name="top"><br><a class="news" href="news.php?article=6y3ehr7j">Comet�Asteroid Link Confirmed</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>14 January  2008<a name="top"><br><a class="news" href="news.php?article=e511t4z2">Astronomical Myths of Mercury & the Sun</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>10 January  2008<a name="top"><br><a class="news" href="news.php?article=66b0jzyh">2008�Year of the Electric Universe</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>30 May  2007<a name="top"><br><a class="news" href="news.php?article=cz0xf230">Io and the Electric Universe</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>17 April  2007<a name="top"><br><a class="news" href="news.php?article=7hjpuqz9">The Astrophysical Crisis at Red Square</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>15 February  2007<a name="top"><br><a class="news" href="news.php?article=aapprbh6">Global Warming in a Climate of Ignorance</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>24 December  2006<a name="top"><br><a class="news" href="news.php?article=hrpk2p16">The Electric Sky�Interview with the author</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>20 November  2006<a name="top"><br><a class="news" href="news.php?article=4egjus1n">The 'Spiral Galaxy' at Saturn's Pole</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>29 October  2006<a name="top"><br><a class="news" href="news.php?article=d4fsrk24">Nobel Prize for Big Bang is a Fizzer</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>16 October  2006<a name="top"><br><a class="news" href="news.php?article=8p6ud5jc">The Real Impact of Victoria Crater</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>30 September  2006<a name="top"><br><a class="news" href="news.php?article=55fx8yeh">Voyager Probes the Sun's Electrical Environment</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>28 August  2006<a name="top"><br><a class="news" href="news.php?article=zc22ejwj">Grey Matter vs Dark Matter</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>30 July  2006<a name="top"><br><a class="news" href="news.php?article=qwk0u6cc">The Madness of Black Holes</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>30 June  2006<a name="top"><br><a class="news" href="news.php?article=d7fec25w">The IEEE, Plasma Cosmology and Extreme Ball Lightning</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>25 May  2006<a name="top"><br><a class="news" href="news.php?article=z65gw0j4">Watch This Space</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>22 April  2006<a name="top"><br><a class="news" href="news.php?article=9aqt6cz5">Venus isn't our twin!</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>14 March  2006<a name="top"><br><a class="news" href="news.php?article=cr8afnuj">Stardust Comet Fragments Solar System Theory</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>13 February  2006<a name="top"><br><a class="news" href="news.php?article=nm613913">First Evidence of Comet Ice � What Does it Mean?</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>01 January  2006<a name="top"><br><a class="news" href="news.php?article=gdaqg8df">A Real 'Theory of Everything'</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>21 December  2005<a name="top"><br><a class="news" href="news.php?article=36uyr9nx">Electric Earthquakes</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>13 November  2005<a name="top"><br><a class="news" href="news.php?article=0yfteeje">Voyager 1 at the Edge � of what?</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>07 October  2005<a name="top"><br><a class="news" href="news.php?article=1dqzp30f">Hyperion's History</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>13 September  2005<a name="top"><br><a class="news" href="news.php?article=gkt34rnp">Comet Tails of the Expected</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>24 August  2005<a name="top"><br><a class="news" href="news.php?article=re6qxnz1">Supernova 1987A Decoded</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>13 July  2005<a name="top"><br><a class="news" href="news.php?article=3kneumjj">Comet Tempel 1's Electrifying Impact</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>03 July  2005<a name="top"><br><a class="news" href="news.php?article=hcabb8zj">The Deep Impact of Comet Theory</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>26 March  2005<a name="top"><br><a class="news" href="news.php?article=xewq47rt">The Dragon Storm</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>08 February  2005<a name="top"><br><a class="news" href="news.php?article=cc6y424y">Columbia downed by Megalightning</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>05 February  2005<a name="top"><br><a class="news" href="news.php?article=1xz2g6tn">Saturn's Strange Hot Spot Explained</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>30 January  2005<a name="top"><br><a class="news" href="news.php?article=n2z18sez">Titan - A Rosetta Stone for early Earth?</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>25 December  2004<a name="top"><br><a class="news" href="news.php?article=21ha5gh9">Megalightning at Saturn</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>25 November  2004<a name="top"><br><a class="news" href="news.php?article=bh5fj7ap">Titan puzzles scientists</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>27 October  2004<a name="top"><br><a class="news" href="news.php?article=0auycyew">The True State of the Universe</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>08 August  2004<a name="top"><br><a class="news" href="news.php?article=42gyu28p">Electrifying Saturn</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>20 July  2004<a name="top"><br><a class="news" href="news.php?article=uf4ty065">Comets Impact Cosmology</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>19 June  2004<a name="top"><br><a class="news" href="news.php?article=f16tg4w1">Cassini's Homecoming</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>30 May  2004<a name="top"><br><a class="news" href="news.php?article=9eq6g3aj">Electric Weather</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>25 April  2004<a name="top"><br><a class="news" href="news.php?article=zg70y10m">Electric Dust Devils</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>12 April  2004<a name="top"><br><a class="news" href="news.php?article=zj49j0u7">An Open Letter to Closed Minds</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>30 March  2004<a name="top"><br><a class="news" href="news.php?article=yk0dspt4">Mystery of Mars' Polar Spirals</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>07 March  2004<a name="top"><br><a class="news" href="news.php?article=tyybhrr8">Black holes tear logic apart</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>04 February  2004<a name="top"><br><a class="news" href="news.php?article=we7zdrqs">Opportunity Favors the Heretic</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>23 January  2004<a name="top"><br><a class="news" href="news.php?article=b50z4mj1">Spirit Chases a Martian Mirage</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>06 January  2004<a name="top"><br><a class="news" href="news.php?article=ayxpdjcb">Comet Wild 2</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>03 January  2004<a name="top"><br><a class="news" href="news.php?article=a9ee0spq">Ockham's Beard</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>16 December  2003<a name="top"><br><a class="news" href="news.php?article=jej1t3c2">The Shiny Mountains of Venus</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>09 November  2003<a name="top"><br><a class="news" href="news.php?article=by2r22xg">THE SUN � Our Variable Star (Update 25 Nov)</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>19 October  2003<a name="top"><br><a class="news" href="news.php?article=9kee2918">Comets & Lightning Jets</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>27 August  2003<a name="top"><br><a class="news" href="news.php?article=0414prqf">Mysterious Mars</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>18 August  2003<a name="top"><br><a class="news" href="news.php?article=rnde0zza">Spiral Galaxies & Grand Canyons</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>02 August  2003<a name="top"><br><a class="news" href="news.php?article=hcr2ue54">Puzzling Star Stuff</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>24 July  2003<a name="top"><br><a class="news" href="news.php?article=pca22stj">Planet Birthing - more evidence</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>24 June  2003<a name="top"><br><a class="news" href="news.php?article=x50hfzxa">Squashed Star Flattens Solar Theory</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>25 May  2003<a name="top"><br><a class="news" href="news.php?article=rbkq9dj2">Planet Birthing</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>09 April  2003<a name="top"><br><a class="news" href="news.php?article=9r90r78d">SETI � The Search for Extraterrestrial Intelligence</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>08 February  2003<a name="top"><br><a class="news" href="news.php?article=r4k29syp">Columbia: Questions of Some Gravity (Update 7 June)</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD>30 November  2002<a name="top"><br><a class="news" href="news.php?article=s9ke93mf">Sunspot Mysteries</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD><br><a href="http://www.holoscience.com/news/news.htm">More news articles</a><br><br></TD></TR></TABLE>
<TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<td colspan=2 height=150></TD>
	</TR>
	<TR>
		<TD WIDTH=126></TD><td>
<td>

<style type="text/css">
.kc img {width:10px; height:10px; position:relative; top:8px}
</style>

<div class="kc">
<!-- Site Meter -->
<script type="text/javascript" src="http://s34.sitemeter.com/js/counter.js?site=s34holoscience">
</script>
<noscript>
<a href="http://s34.sitemeter.com/stats.asp?site=s34holoscience" target="_top">
<img src="http://s34.sitemeter.com/meter.asp?site=s34holoscience" alt="Site Meter" border="0"/></a>
</noscript>
<!-- Copyright (c)2006 Site Meter -->
</div>

</td>

<td>
<br>&copy; Holoscience 2010&nbsp;&nbsp;&nbsp;&copy; Design by <a href="http://www.memyselfandi.com.au">Me Myself & I</a>&nbsp;&nbsp;&nbsp;<a href="http://www.raycon.com.au">Web design by Raycon</a>
</td>
	</TR>
</TABLE>

<!-- Start Quantcast tag -->
<script type="text/javascript" src="http://edge.quantserve.com/quant.js"></script>
<script type="text/javascript">_qacct="p-41DgMPstdEZ2s";quantserve();</script>
<noscript>
<a href="http://www.quantcast.com/p-41DgMPstdEZ2s" target="_blank"><img src="http://pixel.quantserve.com/pixel/p-41DgMPstdEZ2s.gif" style="display: none;" border="0" height="1" width="1" alt="Quantcast"/></a>
</noscript>
<!-- End Quantcast tag -->

</BODY>
</HTML>