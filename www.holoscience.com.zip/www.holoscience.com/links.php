<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<HTML>
<HEAD>
<TITLE>The Electric Universe links page</TITLE>

<META NAME="description" CONTENT="">

<META NAME="keywords" CONTENT="">

<META NAME="author" CONTENT="Raycon">

<BASE href="http://www.holoscience.com/">

<META NAME="MSSmartTagsPreventParsing" content="TRUE">

<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">

<link rel=stylesheet href="local.css" type="text/css">

<SCRIPT LANGUAGE="JavaScript" src="../template/mouseover.js"></SCRIPT>

</HEAD>

<BODY bgcolor="#000000" marginwidth="0" marginheight="0" leftmargin="0" topmargin="0" ONLOAD="self.focus();document.search.keywords.focus();preloadImages();">

<!-- Page header table -->
<TABLE WIDTH=1600 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD><img src="g/linksheader1.jpg" width=604 height=74 border=0 alt="The Electric Universe"></TD>
		<TD><img src="g/internalheader2.gif" width=1 height=74 border=0 alt="The Electric Universe"></TD>
		<TD><img src="g/internalheader3.gif" width=175 height=74 border=0 alt="The Electric Universe"></TD>
		<TD height=74 width=820 BGCOLOR=#000000></TD>
	</TR>
</TABLE>

<!-- Buttons and search bar table -->
<TABLE WIDTH=1600 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<!-- White line -->
		<TD colspan=11 HEIGHT=1 BGCOLOR=#ffffff></TD>
	</TR>
	<TR>
		<TD><img src="g/internalsearch1.gif" WIDTH=25 HEIGHT=27 border=0 alt="The Electric Universe">		</TD>

		<!-- Button template goes here -->
		<TD><A HREF="index.php" ONMOUSEOVER="changeImages('id0', 'gbi/0_over.gif'); return true;"
ONMOUSEOUT="changeImages('id0', 'gbi/0.gif'); return true;">
<IMG NAME="id0" SRC="gbi/0.gif" width="40" height="27" BORDER=0></A></TD>
<TD><A HREF="preface.php" ONMOUSEOVER="changeImages('id1', 'gbi/1_over.gif'); return true;"
ONMOUSEOUT="changeImages('id1', 'gbi/1.gif'); return true;">
<IMG NAME="id1" SRC="gbi/1.gif" width="45" height="27" BORDER=0></A></TD>
<TD><A HREF="news.php" ONMOUSEOVER="changeImages('id2', 'gbi/2_over.gif'); return true;"
ONMOUSEOUT="changeImages('id2', 'gbi/2.gif'); return true;">
<IMG NAME="id2" SRC="gbi/2.gif" width="80" height="27" BORDER=0></A></TD>
<TD><A HREF="synopsis.php" ONMOUSEOVER="changeImages('id3', 'gbi/3_over.gif'); return true;"
ONMOUSEOUT="changeImages('id3', 'gbi/3.gif'); return true;">
<IMG NAME="id3" SRC="gbi/3.gif" width="60" height="27" BORDER=0></A></TD>
<TD><A HREF="links.php" ONMOUSEOVER="changeImages('id4', 'gbi/4_over.gif'); return true;"
ONMOUSEOUT="changeImages('id4', 'gbi/4_over.gif'); return true;">
<IMG NAME="id4" SRC="gbi/4_over.gif" width="40" height="27" BORDER=0></A></TD>
<TD><A HREF="contact.php" ONMOUSEOVER="changeImages('id5', 'gbi/5_over.gif'); return true;"
ONMOUSEOUT="changeImages('id5', 'gbi/5.gif'); return true;">
<IMG NAME="id5" SRC="gbi/5.gif" width="50" height="27" BORDER=0></A></TD>

		<TD><img src="g/internalsearch2.gif" WIDTH=262 HEIGHT=27 border=0 alt="The Electric Universe">		</TD>

		<TD WIDTH=139 HEIGHT=27>
		<!-- Search box table -->

		<TABLE WIDTH=139 BORDER=0 CELLPADDING=0 CELLSPACING=0>
<form name="search" method="post" action="search.php">
		<tr>
			<TD WIDTH=139 HEIGHT=19 valign="middle">
				
				<input type="text" name="keywords" size="22" style="width:139px;height:20px;background-color:#000000;" class="stextw" value="">
			</TD>
		</tr>
		</table>

		</TD>

		<TD><input type="image" src="g/internalsearch3.gif" WIDTH=39 HEIGHT=27 border="0" alt="The Electric Universe">		</TD>
		<TD height=27 width=820 BGCOLOR=#000000></TD>

	</TR>

	<TR>
		<!-- White line -->
		<TD colspan=11 HEIGHT=1 BGCOLOR=#ffffff></TD>
	</TR>


</form>
</TABLE>

<TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0><TD colspan=2 HEIGHT=34></TD></TR><TR><TD WIDTH=126 HEIGHT=10></TD><TD><img src="g/linkstitle.gif" width="32" height="11" border=0></TD></TR><TR><TD colspan=2 HEIGHT=20></TD></TR></TABLE><TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0><TR><TD WIDTH=126></TD><TD><font class="btitle">Thunderbolts - picture of the day archive</font><br>Read breaking news about an alternative Electric Universe explanation of recent news items.<br><a class="links" href="http://www.thunderbolts.info/tpod/00current.htm">http://www.thunderbolts.info/tpod/00current.htm</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD><font class="btitle">The Plasma Universe</font><br>Website of Anthony Peratt, author of Physics of the Plasma Universe.<br><a class="links" href="http://plasmauniverse.info/">http://plasmauniverse.info/</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD><font class="btitle">Plasma Cosmology Papers</font><br><a class="links" href="http://public.lanl.gov/alp/plasma/papers.html">http://public.lanl.gov/alp/plasma/papers.html</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD><font class="btitle">Society for Interdisciplinary Studies</font><br>The oldest and most up to date society for  catastrophist information and research<br><a class="links" href="http://www.knowledge.co.uk/sis/">http://www.knowledge.co.uk/sis/</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD><font class="btitle">Halton Arp - A Modern Day Galileo</font><br>"You can't vote on the truth." No matter how many people believe something, if the observations prove it wrong, it is wrong. Arp presents the observations that show the Big Bang theory is wrong.<br><a class="links" href="http://www.haltonarp.com">http://www.haltonarp.com</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD><font class="btitle">Don Scott: The Electric Cosmos</font><br>A professor of electrical engineering gives his view of how stars really work.<br><a class="links" href="http://www.electric-cosmos.org/">http://www.electric-cosmos.org/</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD><font class="btitle">THOTH email newsletter</font><br>The THOTH Newsletter is available free of charge to anyone with an interest in the expanding discussion of the Saturn Model or the Electric Universe.<br><a class="links" href="http://www.kronia.com/newsletter.asp">http://www.kronia.com/newsletter.asp</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD><font class="btitle">Maverick Science</font><br>Ev Cochrane's development of a unified theory of myth and science�the so-called Saturn theory. The Saturn theory has profound and wide-ranging ramifications for a host of scientific disciplines, including astronomy, planetary geology, psychology, comparative religion, and linguistics among others. Ev is publisher and co-editor (together with Dwardu Cardona) of the journal called Aeon.<br><a class="links" href="http://www.maverickscience.com">http://www.maverickscience.com</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD><font class="btitle">AEON Journal</font><br>AEON is a journal of myth, science, and ancient history specializing in archaeoastronomy and comparative mythology. 

The journal explores the evidence for global catastrophes and interplanetary upheaval in the recent past. It has particular significance for cosmogony and the Electric Universe.<br><a class="links" href="http://www.aeonjournal.com/">http://www.aeonjournal.com/</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD><font class="btitle">Skeptical Investigations</font><br>Skepticism is necessary and healthy, and we would be foolish to believe everything we are told. But genuine skepticism is about open-minded enquiry, not denial. This new website presents an investigation into the true meaning of Skepticism in Science.<br><a class="links" href="http://www.skepticalinvestigations.org/orthodoxies/electric.htm">http://www.skepticalinvestigations.org/orthodoxies/electric.htm</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD><font class="btitle">Mythopedia</font><br>From the second half of the 20th century, cosmologists and geophysicists have made great advances in modelling the electromagnetic environment of the earth in response to the solar wind and other external features impinging on the earth, such as Near-Earth Objects (NEOs) and, far less frequently, cometary intruders into the inner solar system. Our purpose is to consider how knowledge of this kind might aid our understanding of traditional ideas about cosmology and the recent history of the earth, as documented in the history of astronomy, archaeoastronomy and certain classes of mythology and ancient ritual.<br><a class="links" href="http://www.mythopedia.info/">http://www.mythopedia.info/</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD><font class="btitle">Rupert Sheldrake Online</font><br>Author of Seven Experiments That Could Change the World: A Do-It Yourself Guide to Revolutionary Science.    "Science in its ideology sees itself as doing a fearless exploration of the unknown. Most of the time it is a fearful exploration of the almost known."<br><a class="links" href="http://www.sheldrake.org/">http://www.sheldrake.org/</a><br><br></TD></TR><TR><TD WIDTH=126></TD><TD><font class="btitle">Ralph Sansbury's Papers</font><br>A return to a classical physics approach to the nature of magnetism and gravity and their relationship to the electrical structure of matter.<br><a class="links" href="http://mysite.verizon.net/r9ns/">http://mysite.verizon.net/r9ns/</a><br><br></TD></TR></TABLE>
<TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<td colspan=2 height=150></TD>
	</TR>
	<TR>
		<TD WIDTH=126></TD><td>
<td>

<style type="text/css">
.kc img {width:10px; height:10px; position:relative; top:8px}
</style>

<div class="kc">
<!-- Site Meter -->
<script type="text/javascript" src="http://s34.sitemeter.com/js/counter.js?site=s34holoscience">
</script>
<noscript>
<a href="http://s34.sitemeter.com/stats.asp?site=s34holoscience" target="_top">
<img src="http://s34.sitemeter.com/meter.asp?site=s34holoscience" alt="Site Meter" border="0"/></a>
</noscript>
<!-- Copyright (c)2006 Site Meter -->
</div>

</td>

<td>
<br>&copy; Holoscience 2010&nbsp;&nbsp;&nbsp;&copy; Design by <a href="http://www.memyselfandi.com.au">Me Myself & I</a>&nbsp;&nbsp;&nbsp;<a href="http://www.raycon.com.au">Web design by Raycon</a>
</td>
	</TR>
</TABLE>

<!-- Start Quantcast tag -->
<script type="text/javascript" src="http://edge.quantserve.com/quant.js"></script>
<script type="text/javascript">_qacct="p-41DgMPstdEZ2s";quantserve();</script>
<noscript>
<a href="http://www.quantcast.com/p-41DgMPstdEZ2s" target="_blank"><img src="http://pixel.quantserve.com/pixel/p-41DgMPstdEZ2s.gif" style="display: none;" border="0" height="1" width="1" alt="Quantcast"/></a>
</noscript>
<!-- End Quantcast tag -->

</BODY>
</HTML>