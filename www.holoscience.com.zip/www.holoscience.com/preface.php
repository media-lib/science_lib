<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<HTML>
<HEAD>
<TITLE>The Electric Universe Preface</TITLE>

<META NAME="description" CONTENT="">

<META NAME="keywords" CONTENT="">

<META NAME="author" CONTENT="Raycon">

<BASE href="http://www.holoscience.com/">

<META NAME="MSSmartTagsPreventParsing" content="TRUE">

<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">

<link rel=stylesheet href="local.css" type="text/css">

<SCRIPT LANGUAGE="JavaScript" src="../template/mouseover.js"></SCRIPT>

</HEAD>

<BODY bgcolor="#000000" marginwidth="0" marginheight="0" leftmargin="0" topmargin="0" ONLOAD="self.focus();document.search.keywords.focus();preloadImages();">

<!-- Page header table -->
<TABLE WIDTH=1600 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD><img src="g/prefaceheader1.jpg" width=604 height=74 border=0 alt="The Electric Universe"></TD>
		<TD><img src="g/internalheader2.gif" width=1 height=74 border=0 alt="The Electric Universe"></TD>
		<TD><img src="g/internalheader3.gif" width=175 height=74 border=0 alt="The Electric Universe"></TD>
		<TD height=74 width=820 BGCOLOR=#000000></TD>
	</TR>
</TABLE>

<!-- Buttons and search bar table -->
<TABLE WIDTH=1600 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<!-- White line -->
		<TD colspan=11 HEIGHT=1 BGCOLOR=#ffffff></TD>
	</TR>
	<TR>
		<TD><img src="g/internalsearch1.gif" WIDTH=25 HEIGHT=27 border=0 alt="The Electric Universe">		</TD>

		<!-- Button template goes here -->
		<TD><A HREF="index.php" ONMOUSEOVER="changeImages('id0', 'gbi/0_over.gif'); return true;"
ONMOUSEOUT="changeImages('id0', 'gbi/0.gif'); return true;">
<IMG NAME="id0" SRC="gbi/0.gif" width="40" height="27" BORDER=0></A></TD>
<TD><A HREF="preface.php" ONMOUSEOVER="changeImages('id1', 'gbi/1_over.gif'); return true;"
ONMOUSEOUT="changeImages('id1', 'gbi/1_over.gif'); return true;">
<IMG NAME="id1" SRC="gbi/1_over.gif" width="45" height="27" BORDER=0></A></TD>
<TD><A HREF="news.php" ONMOUSEOVER="changeImages('id2', 'gbi/2_over.gif'); return true;"
ONMOUSEOUT="changeImages('id2', 'gbi/2.gif'); return true;">
<IMG NAME="id2" SRC="gbi/2.gif" width="80" height="27" BORDER=0></A></TD>
<TD><A HREF="synopsis.php" ONMOUSEOVER="changeImages('id3', 'gbi/3_over.gif'); return true;"
ONMOUSEOUT="changeImages('id3', 'gbi/3.gif'); return true;">
<IMG NAME="id3" SRC="gbi/3.gif" width="60" height="27" BORDER=0></A></TD>
<TD><A HREF="links.php" ONMOUSEOVER="changeImages('id4', 'gbi/4_over.gif'); return true;"
ONMOUSEOUT="changeImages('id4', 'gbi/4.gif'); return true;">
<IMG NAME="id4" SRC="gbi/4.gif" width="40" height="27" BORDER=0></A></TD>
<TD><A HREF="contact.php" ONMOUSEOVER="changeImages('id5', 'gbi/5_over.gif'); return true;"
ONMOUSEOUT="changeImages('id5', 'gbi/5.gif'); return true;">
<IMG NAME="id5" SRC="gbi/5.gif" width="50" height="27" BORDER=0></A></TD>

		<TD><img src="g/internalsearch2.gif" WIDTH=262 HEIGHT=27 border=0 alt="The Electric Universe">		</TD>

		<TD WIDTH=139 HEIGHT=27>
		<!-- Search box table -->

		<TABLE WIDTH=139 BORDER=0 CELLPADDING=0 CELLSPACING=0>
<form name="search" method="post" action="search.php">
		<tr>
			<TD WIDTH=139 HEIGHT=19 valign="middle">
				
				<input type="text" name="keywords" size="22" style="width:139px;height:20px;background-color:#000000;" class="stextw" value="">
			</TD>
		</tr>
		</table>

		</TD>

		<TD><input type="image" src="g/internalsearch3.gif" WIDTH=39 HEIGHT=27 border="0" alt="The Electric Universe">		</TD>
		<TD height=27 width=820 BGCOLOR=#000000></TD>

	</TR>

	<TR>
		<!-- White line -->
		<TD colspan=11 HEIGHT=1 BGCOLOR=#ffffff></TD>
	</TR>


</form>
</TABLE>

<TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0><TD colspan=2 HEIGHT=34></TD></TR><TR><TD WIDTH=126 HEIGHT=10></TD><TD><img src="g/prefacetitle.gif" width="49" height="11" border=0></TD></TR><TR><TD colspan=2 HEIGHT=20></TD></TR></TABLE><TABLE WIDTH=606 BORDER=0 CELLPADDING=0 CELLSPACING=0><TR><TD WIDTH=126 valign="top"><img src="g/walthornhill.jpg" border="0" width=126 height=78 alt="Wal Thornhill"></TD>
<TD valign="top"><p>If I have had an underlying purpose in my life it has been to watch for intellectual explorers who have been marginalised by their peers. They are often those who have the audacity to use their imagination, uncommon-sense and courage to challenge the paradigm paralysis institutionalised in western science.</p>

<p>It is a truism that breakthroughs often lie unrecognised for decades. "I'll see it when I believe it" could be the catch-cry for much of science. After the slow path to acceptance of each great new idea, it always seems so obvious in retrospect. We teach children in grade school ideas that defeated the greatest intellects for centuries. That being so, we must not let the reputation of even an Einstein stand in our way when seeking better paradigms. We must simply allow for the possibility that he was wrong, recognising that science is a highly conservative captive of fashion.</p>

<p>The Electric Universe opens up science again to the individual. Science will blossom in the new millennium as a cultural activity more integrated with history, the arts and the human condition.</p>
<p align="right"><img src="g/signature.gif" border="0"></p>

</TD></TR></TABLE>
<TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<td colspan=2 height=150></TD>
	</TR>
	<TR>
		<TD WIDTH=126></TD><td>
<td>

<style type="text/css">
.kc img {width:10px; height:10px; position:relative; top:8px}
</style>

<div class="kc">
<!-- Site Meter -->
<script type="text/javascript" src="http://s34.sitemeter.com/js/counter.js?site=s34holoscience">
</script>
<noscript>
<a href="http://s34.sitemeter.com/stats.asp?site=s34holoscience" target="_top">
<img src="http://s34.sitemeter.com/meter.asp?site=s34holoscience" alt="Site Meter" border="0"/></a>
</noscript>
<!-- Copyright (c)2006 Site Meter -->
</div>

</td>

<td>
<br>&copy; Holoscience 2010&nbsp;&nbsp;&nbsp;&copy; Design by <a href="http://www.memyselfandi.com.au">Me Myself & I</a>&nbsp;&nbsp;&nbsp;<a href="http://www.raycon.com.au">Web design by Raycon</a>
</td>
	</TR>
</TABLE>

<!-- Start Quantcast tag -->
<script type="text/javascript" src="http://edge.quantserve.com/quant.js"></script>
<script type="text/javascript">_qacct="p-41DgMPstdEZ2s";quantserve();</script>
<noscript>
<a href="http://www.quantcast.com/p-41DgMPstdEZ2s" target="_blank"><img src="http://pixel.quantserve.com/pixel/p-41DgMPstdEZ2s.gif" style="display: none;" border="0" height="1" width="1" alt="Quantcast"/></a>
</noscript>
<!-- End Quantcast tag -->

</BODY>
</HTML>