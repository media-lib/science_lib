<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<HTML>
<HEAD>
<TITLE>Synopsis of The Electric Universe</TITLE>

<META NAME="description" CONTENT="">

<META NAME="keywords" CONTENT="">

<META NAME="author" CONTENT="Raycon">

<BASE href="http://www.holoscience.com/">

<META NAME="MSSmartTagsPreventParsing" content="TRUE">

<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">

<link rel=stylesheet href="local.css" type="text/css">

<SCRIPT LANGUAGE="JavaScript" src="../template/mouseover.js"></SCRIPT>

</HEAD>

<BODY bgcolor="#000000" marginwidth="0" marginheight="0" leftmargin="0" topmargin="0" ONLOAD="self.focus();document.search.keywords.focus();preloadImages();">

<!-- Page header table -->
<TABLE WIDTH=1600 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD><img src="g/synopsisheader1.jpg" width=604 height=74 border=0 alt="The Electric Universe"></TD>
		<TD><img src="g/internalheader2.gif" width=1 height=74 border=0 alt="The Electric Universe"></TD>
		<TD><img src="g/internalheader3.gif" width=175 height=74 border=0 alt="The Electric Universe"></TD>
		<TD height=74 width=820 BGCOLOR=#000000></TD>
	</TR>
</TABLE>

<!-- Buttons and search bar table -->
<TABLE WIDTH=1600 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<!-- White line -->
		<TD colspan=11 HEIGHT=1 BGCOLOR=#ffffff></TD>
	</TR>
	<TR>
		<TD><img src="g/internalsearch1.gif" WIDTH=25 HEIGHT=27 border=0 alt="The Electric Universe">		</TD>

		<!-- Button template goes here -->
		<TD><A HREF="index.php" ONMOUSEOVER="changeImages('id0', 'gbi/0_over.gif'); return true;"
ONMOUSEOUT="changeImages('id0', 'gbi/0.gif'); return true;">
<IMG NAME="id0" SRC="gbi/0.gif" width="40" height="27" BORDER=0></A></TD>
<TD><A HREF="preface.php" ONMOUSEOVER="changeImages('id1', 'gbi/1_over.gif'); return true;"
ONMOUSEOUT="changeImages('id1', 'gbi/1.gif'); return true;">
<IMG NAME="id1" SRC="gbi/1.gif" width="45" height="27" BORDER=0></A></TD>
<TD><A HREF="news.php" ONMOUSEOVER="changeImages('id2', 'gbi/2_over.gif'); return true;"
ONMOUSEOUT="changeImages('id2', 'gbi/2.gif'); return true;">
<IMG NAME="id2" SRC="gbi/2.gif" width="80" height="27" BORDER=0></A></TD>
<TD><A HREF="synopsis.php" ONMOUSEOVER="changeImages('id3', 'gbi/3_over.gif'); return true;"
ONMOUSEOUT="changeImages('id3', 'gbi/3_over.gif'); return true;">
<IMG NAME="id3" SRC="gbi/3_over.gif" width="60" height="27" BORDER=0></A></TD>
<TD><A HREF="links.php" ONMOUSEOVER="changeImages('id4', 'gbi/4_over.gif'); return true;"
ONMOUSEOUT="changeImages('id4', 'gbi/4.gif'); return true;">
<IMG NAME="id4" SRC="gbi/4.gif" width="40" height="27" BORDER=0></A></TD>
<TD><A HREF="contact.php" ONMOUSEOVER="changeImages('id5', 'gbi/5_over.gif'); return true;"
ONMOUSEOUT="changeImages('id5', 'gbi/5.gif'); return true;">
<IMG NAME="id5" SRC="gbi/5.gif" width="50" height="27" BORDER=0></A></TD>

		<TD><img src="g/internalsearch2.gif" WIDTH=262 HEIGHT=27 border=0 alt="The Electric Universe">		</TD>

		<TD WIDTH=139 HEIGHT=27>
		<!-- Search box table -->

		<TABLE WIDTH=139 BORDER=0 CELLPADDING=0 CELLSPACING=0>
<form name="search" method="post" action="search.php">
		<tr>
			<TD WIDTH=139 HEIGHT=19 valign="middle">
				
				<input type="text" name="keywords" size="22" style="width:139px;height:20px;background-color:#000000;" class="stextw" value="">
			</TD>
		</tr>
		</table>

		</TD>

		<TD><input type="image" src="g/internalsearch3.gif" WIDTH=39 HEIGHT=27 border="0" alt="The Electric Universe">		</TD>
		<TD height=27 width=820 BGCOLOR=#000000></TD>

	</TR>

	<TR>
		<!-- White line -->
		<TD colspan=11 HEIGHT=1 BGCOLOR=#ffffff></TD>
	</TR>


</form>
</TABLE>

<TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0><TD colspan=2 HEIGHT=34></TD></TR><TR><TD WIDTH=126 HEIGHT=10><img src="g/synopsistitle.gif" border="0" WIDTH="81" HEIGHT="11"></TD><TD><img src="g/synopsis1title.gif" width="64" height="11" border=0></TD></TR><TR><TD colspan=2 HEIGHT=20></TD></TR></TABLE><TABLE WIDTH=605 BORDER=0 CELLPADDING=0 CELLSPACING=0><TR><td WIDTH=25></td><TD WIDTH=91 valign="top"><TABLE WIDTH=91 BORDER=0 CELLPADDING=0 CELLSPACING=0>

<tr><td align="right" valign="top"><b>1.</b></td><td valign="top"><a href="synopsis.php?page=1">Preface</a></td></tr>
<tr><td colspan="2" height=3></td></tr>
<tr><td align="right" valign="top"><b>2.</b></td><td valign="top"><a href="synopsis.php?page=2">The Electric Universe</a></td></tr>
<tr><td colspan="2" height=3></td></tr>
<tr><td align="right" valign="top"><b>3.</b></td><td valign="top"><a href="synopsis.php?page=3">A Little History</a></td></tr>
<tr><td colspan="2" height=3></td></tr>
<tr><td align="right" valign="top"><b>4.</b></td><td valign="top"><a href="synopsis.php?page=4">What Big Bang?</a></td></tr>
<tr><td colspan="2" height=3></td></tr>
<tr><td align="right" valign="top"><b>5.</b></td><td valign="top"><a href="synopsis.php?page=5">Electric Galaxies</a></td></tr>
<tr><td colspan="2" height=3></td></tr>
<tr><td align="right" valign="top"><b>6.</b></td><td valign="top"><a href="synopsis.php?page=6">Electric Stars</a></td></tr>
<tr><td colspan="2" height=3></td></tr>
<tr><td align="right" valign="top"><b>7.</b></td><td valign="top"><a href="synopsis.php?page=7">Planets</a></td></tr>
<tr><td colspan="2" height=3></td></tr>
<tr><td align="right" valign="top"><b>8.</b></td><td valign="top"><a href="synopsis.php?page=8">Electrical Cratering</a></td></tr>
<tr><td colspan="2" height=3></td></tr>
<tr><td align="right" valign="top"><b>9.</b></td><td valign="top"><a href="synopsis.php?page=9">Electrical Weather</a></td></tr>
<tr><td colspan="2" height=3></td></tr>
<tr><td align="right" valign="top"><b>10.</b></td><td valign="top"><a href="synopsis.php?page=10">Life Itself</a></td></tr>
<tr><td colspan="2" height=3></td></tr>
<tr><td align="right" valign="top"><b>11.</b></td><td valign="top"><a href="synopsis.php?page=11">Some Basics</a></td></tr>
<tr><td colspan="2" height=3></td></tr>
<tr><td align="right" valign="top"><b>12.</b></td><td valign="top"><a href="synopsis.php?page=12">So What?</a></td></tr>
</table>
<br>
<!-- Remove comment when PDF is ready
<a href="electricuniverse.pdf"><img src="g/downloadpdf.gif" border="0" width="85" height="10" alt="Download PDF"></a>
--></TD><td WIDTH=10></td><TD valign="top"><a name="top"></a><p><font class="newsbeige">�The most merciful thing in the world ... is the inability of the human mind to correlate all its contents... The sciences, each straining in its own direction, have hitherto harmed us little; but someday the piecing together of dissociated knowledge will open up such terrifying vistas of reality... That we shall either go mad from the revelation or flee from the deadly light into the peace and safety of a new dark age.� - H. P. Lovecraft</font></p> 

<p>In a broadly interdisciplinary inquiry such as this, communication itself can pose quite a challenge. Typically, the greatest difficulties in communication will occur when one is questioning something already "known" to be true. On matters of underlying principle, the confidence behind established ideas can be so high that discussion itself may seem quite senseless. This difficulty is aggravated by fragmentation of the process by which information is gathered and evaluated. The specialization of intellectual inquiry carries with it certain risks when assumptions within one discipline rest upon prior assumptions in other disciplines. No one can be an expert on everything, and when considering possibilities outside one's personal expertise, it is only natural to defer to what specialists in other studies claim to know. But what are the consequences of this when theoretical suppositions, though perceived as fact, cannot account for compelling new fields of data?</p> 

<p>Given the extreme fragmentation of established science today it is difficult to imagine that the enterprise as a whole could ever "correlate all its contents." Yet extraordinary strides toward that "someday" envisioned by Lovecraft may now be possible through a new approach - one in which electrical phenomena receive the full attention they deserve, and all appropriate fields of evidence are included. To some, the prospects may appear every bit as disturbing as Lovecraft imagined. But for those who instinctively seek out unifying principles, the new horizons will be at once breathtaking and hopeful.</p> 

<p>This introduction will present a new "deep focus lens" for viewing the physical universe, from sub-atomic particles to galactic realms unknown before the Hubble telescope. The Electric Universe is a holistic answer to myopia* -that narrowing of vision which naturally accompanies the fragmentation of knowledge and learning. For those with the courage to see clearly, the required "unlearning" of fashionable ideas carries no real cost whatsoever. The terror Lovecraft envisioned is only the first rush of uncertainty, when ideas long taken for granted are thrown into question by facts and simple reasoning previously ignored. The "piecing together of dissociated knowledge" will only require us to confront the deep contradictions in things experts have long claimed to know. With the courage to see clearly, the adventure itself could well be "the most merciful thing in the world," adding new insights into the greatest dramas of early human history and vital perspective to humanity's situation in the cosmos. Lovecraft did not realize that the "terrifying vistas" are but a mirage seen through an open door. The truth is always unified, and as such it can only be friendly to those who seek the truth first. As we pass through the door, it is not fear that goes with us, but the exhilaration of discovery.</p> 

<p align="right">- Wal Thornhill / David Talbott</p>

 

<p>*Myopia - a disinclination to acknowledge the existence of something.  
</p><br><br><a href="synopsis.php?page=1#top">Back to top</a><br><br><a href="synopsis.php?page=2">Next page</a></TD></TR>
<TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<td colspan=2 height=150></TD>
	</TR>
	<TR>
		<TD WIDTH=126></TD><td>
<td>

<style type="text/css">
.kc img {width:10px; height:10px; position:relative; top:8px}
</style>

<div class="kc">
<!-- Site Meter -->
<script type="text/javascript" src="http://s34.sitemeter.com/js/counter.js?site=s34holoscience">
</script>
<noscript>
<a href="http://s34.sitemeter.com/stats.asp?site=s34holoscience" target="_top">
<img src="http://s34.sitemeter.com/meter.asp?site=s34holoscience" alt="Site Meter" border="0"/></a>
</noscript>
<!-- Copyright (c)2006 Site Meter -->
</div>

</td>

<td>
<br>&copy; Holoscience 2010&nbsp;&nbsp;&nbsp;&copy; Design by <a href="http://www.memyselfandi.com.au">Me Myself & I</a>&nbsp;&nbsp;&nbsp;<a href="http://www.raycon.com.au">Web design by Raycon</a>
</td>
	</TR>
</TABLE>

<!-- Start Quantcast tag -->
<script type="text/javascript" src="http://edge.quantserve.com/quant.js"></script>
<script type="text/javascript">_qacct="p-41DgMPstdEZ2s";quantserve();</script>
<noscript>
<a href="http://www.quantcast.com/p-41DgMPstdEZ2s" target="_blank"><img src="http://pixel.quantserve.com/pixel/p-41DgMPstdEZ2s.gif" style="display: none;" border="0" height="1" width="1" alt="Quantcast"/></a>
</noscript>
<!-- End Quantcast tag -->

</BODY>
</HTML>