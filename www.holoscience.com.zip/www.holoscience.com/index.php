<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<HTML>
<HEAD>
<TITLE>The Electric Universe</TITLE>

<META NAME="description" CONTENT="">

<META NAME="keywords" CONTENT="">

<META NAME="author" CONTENT="Raycon">

<BASE href="http://www.holoscience.com/">

<META NAME="MSSmartTagsPreventParsing" content="TRUE">

<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">

<link rel=stylesheet href="local.css" type="text/css">

<SCRIPT LANGUAGE="JavaScript" src="../template/mouseover.js"></SCRIPT>

</HEAD>

<BODY background="g/background.jpg" marginwidth="0" marginheight="0" leftmargin="0" topmargin="0" ONLOAD="self.focus();document.search.keywords.focus();preloadImages();">

<!-- Page header table -->
<TABLE WIDTH=1600 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD><img src="g/homeheader1.jpg" width=604 height=74 border=0 alt="The Electric Universe"></TD>
		<TD><img src="g/homeheader2.gif" width=1 height=74 border=0 alt="The Electric Universe"></TD>
		<TD><img src="g/homeheader3.gif" width=175 height=74 border=0 alt="The Electric Universe"></TD>
		<TD height=74 width=820 BGCOLOR=#000000></TD>
	</TR>
</TABLE>

<!-- Buttons and search bar table -->
<TABLE WIDTH=1600 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<!-- White line -->
		<TD colspan=11 HEIGHT=1 BGCOLOR=#ffffff></TD>
	</TR>
	<TR>
		<TD><img src="g/homesearch1.gif" WIDTH=25 HEIGHT=27 border=0 alt="The Electric Universe">		</TD>

		<!-- Button template goes here -->
		<TD><A HREF="index.php" ONMOUSEOVER="changeImages('id0', 'gbh/0_over.gif'); return true;"
ONMOUSEOUT="changeImages('id0', 'gbh/0_over.gif'); return true;">
<IMG NAME="id0" SRC="gbh/0_over.gif" width="40" height="27" BORDER=0></A></TD>
<TD><A HREF="preface.php" ONMOUSEOVER="changeImages('id1', 'gbh/1_over.gif'); return true;"
ONMOUSEOUT="changeImages('id1', 'gbh/1.gif'); return true;">
<IMG NAME="id1" SRC="gbh/1.gif" width="45" height="27" BORDER=0></A></TD>
<TD><A HREF="news.php" ONMOUSEOVER="changeImages('id2', 'gbh/2_over.gif'); return true;"
ONMOUSEOUT="changeImages('id2', 'gbh/2.gif'); return true;">
<IMG NAME="id2" SRC="gbh/2.gif" width="80" height="27" BORDER=0></A></TD>
<TD><A HREF="synopsis.php" ONMOUSEOVER="changeImages('id3', 'gbh/3_over.gif'); return true;"
ONMOUSEOUT="changeImages('id3', 'gbh/3.gif'); return true;">
<IMG NAME="id3" SRC="gbh/3.gif" width="60" height="27" BORDER=0></A></TD>
<TD><A HREF="links.php" ONMOUSEOVER="changeImages('id4', 'gbh/4_over.gif'); return true;"
ONMOUSEOUT="changeImages('id4', 'gbh/4.gif'); return true;">
<IMG NAME="id4" SRC="gbh/4.gif" width="40" height="27" BORDER=0></A></TD>
<TD><A HREF="contact.php" ONMOUSEOVER="changeImages('id5', 'gbh/5_over.gif'); return true;"
ONMOUSEOUT="changeImages('id5', 'gbh/5.gif'); return true;">
<IMG NAME="id5" SRC="gbh/5.gif" width="50" height="27" BORDER=0></A></TD>

		<TD><img src="g/homesearch2.gif" WIDTH=262 HEIGHT=27 border=0 alt="The Electric Universe">		</TD>

		<TD WIDTH=139 HEIGHT=27>
		<!-- Search box table -->

		<TABLE WIDTH=139 BORDER=0 CELLPADDING=0 CELLSPACING=0>
<form name="search" method="post" action="search.php">
		<tr>
			<TD WIDTH=139 HEIGHT=19 valign="middle">
				
				<input type="text" name="keywords" size="22" style="width:139px;height:20px;background-color:#000000;" class="stextw" value="">
			</TD>
		</tr>
		</table>

		</TD>

		<TD><input type="image" src="g/homesearch3.gif" WIDTH=39 HEIGHT=27 border="0" alt="The Electric Universe">		</TD>
		<TD height=27 width=820 BGCOLOR=#000000></TD>

	</TR>

	<TR>
		<!-- White line -->
		<TD colspan=11 HEIGHT=1 BGCOLOR=#ffffff></TD>
	</TR>


</form>
</TABLE>


<TABLE WIDTH=1600 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<!-- Space above Electric Universe title -->
		<TD colspan=2 HEIGHT=127></TD>
	</TR>
	<TR>
		<!-- Electric Universe title -->
		<TD WIDTH=368 HEIGHT=13></TD>
		<TD><img src="g/hometitle.gif" WIDTH=167 HEIGHT=13 border=0 alt="The Electric Universe"></TD>
	</TR>
</TABLE>
<table width=780 border=0 cellpadding=0 cellspacing=0>
  <tr>
    <!-- Space below Electric Universe title -->
    <td colspan=2 height=152></td>
  </tr>
  <tr>
    <td colspan="2"><img src="/img/imgoct04/announcements.gif" width="158" height="17"></td>
  </tr>
  <tr valign="middle">
    <td colspan="2"></td>
  </tr>
  <tr valign="top">
    <td width=40><font class="body"><img src="/img/imgoct04/dot-yellow.gif" width="40" height="14"></font></td>
    <td><font class="body"><!-- WAL START EDIT HERE -->See <a
href="http://www.thunderbolts.info/tpod/00current.htm" target="_blank"
title="www.thunderbolts.info Picture of the Day" alt="Link to
www.thunderbolts.info Picture of the Day">THUNDERBOLTS PICTURE
OF THE DAY</a> <br>for breaking Electric Universe news.<br><!-- WAL END EDIT HERE --></font></td>
  </tr>
  <tr valign="middle">
    <td height=20 colspan="2"></td>
  </tr>
  <tr>
    <td colspan="2"><img src="/img/imgoct04/news.gif" width="158" height="17"></td>
  </tr>
  <tr>
    <!-- Space below Text box title -->
    <td colspan=2></td>
  </tr>
</table>
<TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0><TR><TD><a href="news.php?article=ah63dzac"><img src="/img/imgoct04/dot-red.gif" width=40 height=10 border=0 alt="The Electric Universe"></a></TD><TD  WIDTH=2></TD><TD  WIDTH=741 align="left"><font class="body">01/03/2010 <b><a href="news.php?article=ah63dzac">Our Misunderstood Sun</a></b></font></TD></TR><TR><TD colspan=2 HEIGHT=10></TD></TR><TR><TD><a href="news.php?article=8pjd9xpp"><img src="/img/imgoct04/dot-red.gif" width=40 height=10 border=0 alt="The Electric Universe"></a></TD><TD  WIDTH=2></TD><TD  WIDTH=741 align="left"><font class="body">23/12/2009 <b><a href="news.php?article=8pjd9xpp">Science, Politics and Global Warming</a></b></font></TD></TR><TR><TD colspan=2 HEIGHT=10></TD></TR><TR><TD><a href="news.php?article=74fgmwne"><img src="/img/imgoct04/dot-red.gif" width=40 height=10 border=0 alt="The Electric Universe"></a></TD><TD  WIDTH=2></TD><TD  WIDTH=741 align="left"><font class="body">20/10/2009 <b><a href="news.php?article=74fgmwne">Electric Sun Verified</a></b></font></TD></TR>
<table width=780 border=0 cellpadding=0 cellspacing=0>
  <tr>
    <td colspan="2"><p style="font-family: Helvetica, Arial, sans-serif; text-size: 6pt; margin-left: 30px;">PURCHASE</p></td>
  </tr>
  <tr valign="top">
    <td width=40><font class="body"><img src="/img/imgoct04/dot-red.gif" width="40" height="14" border="0"></font></td>
	<td><a href="http://www.thunderboltsproject.com/Ebooks.html" title="Purchase Thunderbolts Project e-books">Thunderbolts Project e-books</a></td>
  </tr>
  <tr valign="top">
    <td width=40><font class="body"><img src="/img/imgoct04/dot-red.gif" width="40" height="14" border="0"></font></td>
	<td><a href="http://www.mikamar.biz/book-info/teu-a.htm" title="Purchase the book, The Electric Universe">Electric Universe book</a></td>
  </tr>
  <tr valign="top">
    <td width=40><font class="body"><img src="/img/imgoct04/dot-red.gif" width="40" height="14" border="0"></font></td>
	<td><a href="http://www.thunderboltsdvd.com/purchase.html" title="Purchase Thunderbolts of the Gods">Thunderbolts of the Gods book and DVD</a></td>
  </tr>
</td>  
</table>
<TR><TD><p id="eu"><a href="http://www.mikamar.biz/book-info/teu-a.htm" title="Purchase the book, The Electric Universe"> <span></span></a></p><p id="tg"><a href="http://www.thunderboltsdvd.com/purchase.html" title="Purchase Thunderbolts of the Gods"> <span></span></a></p></TD><TR></TABLE>
<TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<td colspan=2 height=150></TD>
	</TR>
	<TR>
		<TD WIDTH=43></TD><td>
<td>

<style type="text/css">
.kc img {width:10px; height:10px; position:relative; top:8px}
</style>

<div class="kc">
<!-- Site Meter -->
<script type="text/javascript" src="http://s34.sitemeter.com/js/counter.js?site=s34holoscience">
</script>
<noscript>
<a href="http://s34.sitemeter.com/stats.asp?site=s34holoscience" target="_top">
<img src="http://s34.sitemeter.com/meter.asp?site=s34holoscience" alt="Site Meter" border="0"/></a>
</noscript>
<!-- Copyright (c)2006 Site Meter -->
</div>

</td>

<td>
<br>&copy; Holoscience 2010&nbsp;&nbsp;&nbsp;&copy; Design by <a href="http://www.memyselfandi.com.au">Me Myself & I</a>&nbsp;&nbsp;&nbsp;<a href="http://www.raycon.com.au">Web design by Raycon</a>
</td>
	</TR>
</TABLE>

<!-- Start Quantcast tag -->
<script type="text/javascript" src="http://edge.quantserve.com/quant.js"></script>
<script type="text/javascript">_qacct="p-41DgMPstdEZ2s";quantserve();</script>
<noscript>
<a href="http://www.quantcast.com/p-41DgMPstdEZ2s" target="_blank"><img src="http://pixel.quantserve.com/pixel/p-41DgMPstdEZ2s.gif" style="display: none;" border="0" height="1" width="1" alt="Quantcast"/></a>
</noscript>
<!-- End Quantcast tag -->

</BODY>
</HTML>