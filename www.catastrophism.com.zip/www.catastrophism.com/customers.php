<html>
<head>
<title>Catastrophism! Man, Myth and Mayhem in Ancient History and the Sciences. CD-Rom disc</title>

<META NAME="description" CONTENT="Have there been worldwide catastrophes in mankind's more recent past? This site offers resources and valuable information to help you decide.">

<META NAME="keywords" CONTENT="catastrophism, catastrophics, catastrophes, catastrophists, interdisciplinary, mythology, folklore, archaeoastronomy, ancient history, geomagnetism, palaeontology, archaeology, biblical studies, cosmology, astronomy, geology, physics, evolution, psychology, asteroid impacts, plasma cosmology, Immanuel Velikovsky, the electric universe">

<META NAME="ROBOTS" CONTENT="ALL, FOLLOW">

</head>
<body text="white" bgcolor="black" link="cyan" vlink="blue">

<center>
<TABLE BORDER="0" CELLPADDING="2" CELLSPACING="0" width="70%"><tr><td>
<center>
<h1>Catastrophism!</h1>
<b>Man, Myth and Mayhem in Ancient History and the Sciences</b>
<P>
<img src="earth.gif" width=192 height=192 border=0>
<P>
</center>


<center>
<a href="index.htm">Home</a>
<p><br>

<table width=600><tr><td><font face="arial,helvetica">
<font size="+1">Links to Web sites of Interest</font>

<style type="text/css">
a.tiny {font-size:80%}
</style>


<font face="arial,helvetica">
<h3>Clients of <a href="http://www.knowledge.co.uk">Knowledge Computing</a>, Web designer</h3>
<b>Return to <a href="/">Home Page</a></b>
<p>
<ol style="margin-left:20px">
<li><b><a href="http://www.626110432547f398491fad32d6add11b.com">www.626110432547f398491fad32d6add11b.com</a></b>: Lost TV Series: Solving/decrypting the Hash Code
<li><b><a href="http://www.activedocuments.co.uk">Active Documents</a></b>: knowledge sharing and document management
<li><b><a href="http://www.adairs.co.uk">Adairs Driving Instruction</a></b>: in and around Newcastle and North Tyneside
<li><b><a href="http://www.aeonJournal.com">Aeon</a></b>: The Journal of Myth and Science
<li><b><a href="http://www.albany-roofing.co.uk/">Albany Roofing</a></b>: Derby roofing repair
<li><b><a href="http://www.all4kidsuk.com">All4kidsUK</a></b>: the directory of what to do and what's on for children
<li><b><a href="http://www.andyscott.org.uk">Andy Scott</a></b>: composer and saxophonist
<li><b><a href="http://www.apollosaxophonequartet.com">Apollo Saxophone Quartet</a></b>: jazz ensemble
<li><b><a href="http://www.archaeoastronomy.info">archaeoastronomy.info</a></b>: Information on archeoastronomy
<li><b><a href="http://www.arabesque-duo.co.uk/index.htm">Arabesque Duo</a></b>: Flute and Harp Duo  [<a href="http://www.arabesque-duo.com/">More</a>]
<li><b><a href="http://www.artmasters.co.uk/"> Art Masters</a></b>: original fine art and limited edition prints
<li><b><a href="http://www.ashdown-drive.co.uk">Ashdown Drive</a></b>: street in Borehamwood, Herts
<li><b><a href="http://www.astute-music.com/">Astute Music</a></b>: Music publishers of sheet music and CDs
<li><b><a href="http://www.beechoakfarm.co.uk/">Beech Oak Farm</a></b>: Montessori Pre School
<li><b><a href="http://www.big-brother-news.com/">Big Brother News</a></b>: about the hit TV series 
<li><b><a href="http://www.british-jewry-book.co.uk">British Jewry Book of Honour</a></b>: honoring WWI British Jewish soldiers
<li><b><a href="http://celebrity.big-brother-news.com/">Celebrity Big Brother News</a></b>: about the Celebs Version 
<li><b><a href="http://www.tanandnails.co.uk">Carly Marsden</a></b>: mobile Bio Sculpture gel nails, tanning and beautician
<li><b><a href="http://www.catastrophism.co.uk">Catastrophism!</a></b>: 4,000 articles online or on CD-Rom
<li><b><a href="http://www.centuries.co.uk">Centuries of Darkness</a></b>: the book on ancient chronology by Peter James
<li><b><a href="http://www.charlesandfitch.co.uk">Charles & Fitch</a></b>: Independent Financial Adviser
<li><b><a href="http://www.copy-doctor.co.uk/">Copy Doctor</a></b>: Professional Copywriting
<li><b><a href="http://www.coda.org.uk/">CODA Music Trust</a></b>: Music education
<li><b><a href="http://www.funfair-carnivals.co.uk">Cogger's Nationwide Amusement</a></b>: (Funfair hire)
<li><b><a href="http://www.re-date.com/">The Creative Anniversary Calculator</a></b>: Work out the day of your next big anniversary
<li><b><a href="http://www.dating-tips.info">dating-tips.info</a></b>: Hints and tips on getting a date
<li><b><a href="http://www.deafbooks.com/">Deaf Internet Bookstore</a></b>: Jackson and Jackson Publishers
<li><b><a href="http://www.electric-cosmos.org">Electric Cosmos</a></b>: a giant paradigm shift
<li><b><a href="http://www.electricuniverse.info">Electric Universe</a></b>: fact file
<li><b><a href="http://www.essays-direct.com">Essays Direct</a></b>: in all subject to help you revise
<li><b><a href="http://www.family-crests.info/">Family Crests</a></b>: The Book online
<li><b><a href="http://www.family-tree-software.info">Family Tree Software</a></b> [<a href="http://www.family-tree-software.biz/">More</a>] [<a href="http://www.genealogy-software.biz/">More</a>]
<li><b><a href="http://www.law-tuition.co.uk">Finchley Law Tutors</a></b>: private law tuition
<li><b><a href="http://www.finzifriends.org.uk/">Finzi's Friends</a></b>: furthering interest in Gerald Finzi's life

<li><b><a href="http://www.furzehill-school.co.uk">Furzehill School</a></b>: site for former pupils and staff
<li><b><a href="http://www.guildford-house-let.co.uk">Guildford House for Rent</a></b>: Guildford House for Let
<li><b><a href="http://www.herts-squash.org.uk">Hertfordshire Squash Rackets Association</a></b>
<li><b><a href="http://www.hiya4kids.co.uk/">Hiya Kids</a></b> traditional wooden toys
<li><b><a href="http://www.homeworking.com">Homeworking.com</a></b>: the number one resource for people wanting to work from home [<a href="http://www.homeworking.org/">More</a>]
<li><b><a href="http://www.homeworking.biz">Homeworking.biz</a></b>: Homeworking jobs, contract and freelance work
<li><b><a href="http://www.housman-society.co.uk/">Housman Society</a></b>: an appreciation of the life and works of A.E. Housman
<li><b><a href="http://www.intbis.com">Integrated Business and information Systems Ltd</a></b>: building Decision
Support (DS) and Expert Systems
<li><b><a href="http://www.hypnotherapy-jan.co.uk/">Jan Preistner GQHP Hypnotherapy</a></b>, NLP, EFT (Greater Manchester)
<li><b><a href="http://www.jonforbes.com/">John Forbes</a></b>: Odd Bod Artist
<li><b><a href="http://www.jr-beauty.co.uk/">Julie Root Beauty Therapist</a></b>: St Albans, Hertfordshire
<li><b><a href="http://www.kentaustin.co.uk">Kent Austin</a></b>: Copywriter
<li><b><a href="http://www.kronos-press.com">Kronos Press</a></b>: catastrophist publishers
<li><b><a href="http://www.landcroft.co.uk/">Landcroft Computing</a></b>: software for Law Costs Draftsmen and Jewellers
<li><b><a href="http://www.lauren-scott-harp.co.uk/">Lauren-Scott-Harp.co.uk/</a></b>: Harpist, solo, recital, and freelance
<li><b><a href="http://www.lobster-magazine.co.uk">Lobster</a></b>: The journal of parapolitics, intelligence and State Research
<p>
<li>London Business Services group:
<p>
<table style="width:auto;border:1px solid #aaaaaa"><tr valign=top><td>
<ul>
<li><a href="http://www.london-business-services.co.uk" class="tiny">London Business Services</a>
<li><a href="http://www.londonmailaccommodationaddress.com" class="tiny">London Mail Accommodation Address</a>
<li><a href="http://www.londonmailredirection.com" class="tiny">London Mail Redirection</a>
<li><a href="http://www.londonpoboxes.com" class="tiny">London PO Boxes</a>
<li><a href="http://www.ukmailaccommodationaddress.com" class="tiny">UK Mail Accommodation Address</a>
<li><a href="http://www.ukmailredirection.com" class="tiny">UK Mail Redirection</a>
<li><a href="http://mailredirection.co.uk" class="tiny">Mail Redirection</a>
</td><td><ul>
<li><a href="http://www.ukpoboxes.com" class="tiny">UK PO Boxes</a>
<li><a href="http://www.ukmailboxes.com" class="tiny">UK Mail Boxes</a>
<li><a href="http://www.london-mail-drop.com" class="tiny">London Mail Drop</a>
<li><a href="http://www.london-business-centre.com" class="tiny">London Business Centre</a>
<li><a href="http://www.london-mailboxes.com" class="tiny">London Mailboxes</a>
<li><a href="http://www.london-mailing-address.com" class="tiny">London Mailing Address</a>
</td><td><ul>
<li><a href="http://www.uk-maildrop.com" class="tiny">UK  Maildrop</a>
<li><a href="http://www.uk-business-centre.com" class="tiny">UK Business Centre</a>
<li><a href="http://www.uk-mailing-address.com" class="tiny">UK Mailing Address</a>
<li><a href="http://www.london-virtualoffice.com" class="tiny">London Virtual Office</a>
<li><a href="http://www.uk-virtualoffice.com" class="tiny">UK Virtual Office</a>
<li><a href="http://www.london-business-services.com" class="tiny">London Business Services</a>
</ul>
</td></tr></table>

<LI class="iffy"><b><a href="http://www.male-pattern-baldness.biz">Male Pattern Baldness Treatment</a></b>: Buy Propecia Mail Order
<li><b><a href="http://www.maverickscience.com/">Maverick Science</a></b>: Mythology, science, catastrophsim
<!--LI><b><a href="http://www.mcneillgallery.com">The McNeill Gallery</a></b>: of fine art [<a href="http://www.artmasters.co.uk">More</a>] <---- -->
<li><b><a href="http://www.mud.co.uk">Multi-User Entertainments</a></b>: Internet games software house. 
<li><b><a href="http://www.ukstars.co.uk">Mike Malley Entertainments</a></b>: Bands, Groups, Acts, Booking Agent
<li><b><a href="http://www.modernmusicpublishing.co.uk/">Modern Music Publishing</a></b>: specialising in music for small chamber groups and the
theatre
<li><b><a href="http://www.mri.ac.uk">Music Research Institute</a></b>
<li><b><a href="http://www.body-beauty.co.uk/">My Gorgeous Bod</a></b>, mobile beauty therapist in South Cheshire
<li><b><a href="http://www.mythopedia.info">Mythopedia</a></b>: a new science of myth
<li><b><a href="http://www.nchimatrust.org/">Nchima Trust</a></b>: providing funds for projects in Malawi
<li><b><a href="http://www.nsstudio.co.uk">Neal Scanlan Studio</a></b>: oscar-winning animatronics and special effects in the film industry
<li><b><a href="http://www.old-biddy.com">old-biddy.com</a></b>
<li><b><a href="http://www.paulmitchell-davidson.com/">Paul Mitchell-Davidson</a></b> Composer &bull; Teacher &bull; Educator &bull; Arranger &bull; Musician
<li><b><a href="http://www.pkp-balance.com/">PKP Balance</a></b>
<li><b><a href="http://www.plasma-universe.com">Plasma Universe</a></b>: the Plasma Universe
<li><b><a href="http://www.polarpublishing.com">Polar Publishing</a></b>: the Environment of Violence series of books
<li><b><a href="http://www.precious-metal-recovery.co.uk/">Precious metal recovery</a></b>: Gold, silver, platinum and precious metal recovery
<li><b><a href="http://www.raremetalsreclamation.co.uk/">Rare Metals Reclamation</a></b>: including tungsten, Platinum, rhodium, and non-ferrous
<li><b><a href="http://www.rare-commodities.co.uk/">Rare Commodities</a></b>: purchased, including gold, silver, palladium, tin
<li><b><a href="http://www.robbuckland.com/">Rob Buckland</a></b>: saxophonist
<li><b><a href="http://www.rems-st.co.uk/">The REMS Project</a></b>
<li><b><a href="http://www.richard-strauss-society.co.uk">Richard Strauss Society</a></b>
<li><b><a href="http://www.rucksackmusic.co.uk">Rucksack Music</a></b>: music for kids around London (<a href="http://www.rucksackmusic.co.im/">Isle of Man</a>)
<li><b><a href="http://www.russell-gillespie.com">Russell Gillespie</a></b>: Flautist
<li><b><a href="http://www.sandbach-concert-series.co.uk/">Sandbach Concert Series</a></b> 
<li><b><a href="http://www.sandbach-star.org.uk/">Sandbach Traders and Retailers</a></b> 
<li><b><a href="http://www.sandbach-reflexology.co.uk">Sandbach Reflexology</a></b>
<li><b><a href="http://www.schreibkraft.info/">SchreibKraft</a></b> 
<li><b><a href="http://www.science-frontiers.com">Science Frontiers</a></b>: the digest of reports that describe scientific anomalies
<li><b><a href="http://www.scrap-metal-recovery.co.uk/">Scrap Metal Recovery</a></b>
<li><b><a href="http://www.science-frontiers.com">Science Frontiers</a></b>: the digest of reports that describe scientific anomalies
<li><b><a href="http://www.simonerebello.com/">Simone Rebello</a></b>: percussionist in the UK, Japan and Worldwide
<li><b><a href="http://www.sis-group.org.uk/">Society for Interdisciplinary Studies</a></b>: Catastrophism, Velikovsky etc
<li><b><a href="http://www.song-at-your-service.co.uk/">Song at your Service</a></b> with Joy Naylor.
<li><b><a href="http://www.stjames-junior.co.uk/">St James' C.E.(A.) Junior School</a></b> Derby
<li><b><a href="http://www.stonehenge-info.org">Stonehenge Solved</a></b> Its Three Observatories, Who built them, How and Why
<li><b><a href="http://www.storkremovals.co.uk/">Stork Removals</a></b>: Greater London to anywhere in mainland Britain
<li><b><a href="http://www.surname-origins.com/pages/">Surname Origins</a></b>: Their Source and Significations 
<li><b><a href="http://www.sycopel.com">Sycopel Scientific Ltd</a></b>: Manufacturer of Electrochemical and Medical Instrumentation
<li><b><a href="http://www.tac-au-tac.co.uk/">Tac-au-Tac Dance Schoo</a></b>
<li><b><a href="http://www.tantrichealing.co.uk/">Tantric Healing</a></b>: Holistic Tantric Massage Therapy for Men and Women
<li><b><a href="http://www.tony-hughes.co.uk">Tony Hughes</a></b>: Pianist &bull; Accompanist &bull; Teacher &bull; Singer, based in Nantwich, Cheshire, North West England
<li><b><a href="http://www.toppropertyinvestments.co.uk/">Top Property Investments</a></b>: Property investment opportunity
<li><b><a href="http://www.tresman.co.uk/">Tresman family</a></b>: Personal site and Tresman family tree
<li><b><a href="http://www.velikovskian.com">The Velikovskian</a></b>: a journal investigating the works and ideas of Immanuel Velikovsky
<li><b><a href="http://www.velikovsky.info/">The Velikovsky Encyclopedia</a></b>, The verifiable guide to the subjects, the people, the criticisms, the rebuttals, and the Affair.
<li><b><a href="http://www.vemasat.com">Vemasat</a></b>: Research Institute

<li><b><a href="http://www.web-scripts.biz/">web-scripts.biz</a></b>: PHP script source
<li><b><a href="http://www.whattodoifyouareindebt.co.uk">What to doif you are in Debt</a></b>, advice
<li><b><a href="http://www.youhaventlived.com">You Haven't Lived</a></b>: online games
<li><b><a href="http://www.zephyrwinds.co.uk/">Zephyr Winds</a></b>: Wind Ensemble
<li class="iffy"><b><a href="http://www.abcdating.co.uk">ABC Dating (UK)</a></b>: premier UK online dating service. <a href="http://www.abcdating.com">(World)</a>

<!--- SELF SERVICE CLIENTES --->
<p>
Other pages:
<p>

<li class="iffy"><b><a href="http://www.1stbat.com/">1st Bat</a></b>: Sports goods from eBay
<li class="iffy"><b><a href="http://www.1stBets.com">1st Bets</a></b>: online casino, blackjack to poker
<li><b><a href="http://www.1stfee.com">1st Fee</a></b>: Goods from eBay [<a href="http://www.fees-1st.com/">More</a>]
<li><b><a href="http://www.1st-names.com">1st-names.com</a></b>: Domain names for sale
<li><b><a href="http://www.ad-rates.com/">Ad Rates</a></b>: items from eBay
<li><b><a href="http://www.best-business.info/">Best Business Info</a></b>
<li><b><a href="http://www.best-flight.info">Best Flight Prices info</a></b>: Cheap flights and holidays worldwide
<li><b><a href="http://www.bestflight.info">Best Flight Prices info</a></b>: Cheap flights and holidays worldwide
<li><b><a href="http://www.best-hotel.info/">Best Hotel Prices info</a></b>: Cheap hotels worldwide
<li><b><a href="http://www.best-loans.info/">Best Loans  info</a></b>
<li><b><a href="http://www.fares-1st.com/">Fares First</a></b> Discount fares
<li><b><a href="http://www.ratecard.co.uk/">Rate Card</a></b> 
<li><b><a href="http://www.home-employment.co.uk/">Home Employment Advice</a></b> 
<li><b><a href="http://www.make-money-at-home.co.uk/">Make Money at Home</a></b> 
<li><b><a href="http://www.money-making.co.uk/">Money Making advice</a></b>
<li><b><a href="http://www.stuffing-envelopes.co.uk/">Stuffing Envelopes advice</a></b>
<li><b><a href="http://www.telecommuter.co.uk/">Telecommuter advice</a></b>
<li><b><a href="http://www.work-at-home.co.uk/">Work At Home advice</a></b>
<li><b><a href="http://www.working-at-home.co.uk/">Working At Home advice</a></b>
<li><b><a href="http://www.debt-help.co.uk/">Debt Help advice</a></b>
<li><b><a href="http://www.get-out-of-debt.co.uk/">How to get out of debt advice</a></b>
<li><b><a href="http://www.tresman.co.uk/house/">Derby House for sale</a></b>
<li><b><a href="http://www.knowledge.co.uk/excel-to-html/">MS Excel Spreadhseet to HTML Converter</a></b>
<li><b><a href="http://www.zazzle.com/plasmoid">Electric Universe Store</a></b>

</ul><p>
<font color="#555555">Sun 18 Jul 2010</font>
<p>

<!--WEBBOT bot="HTMLMarkup" startspan ALT="Site Meter" -->
<script type="text/javascript" language="JavaScript">var site="sm2kc-clients"</script>
<script type="text/javascript" language="JavaScript1.2" src="http://sm2.sitemeter.com/js/counter.js?site=sm2kc-clients">
</script>
<noscript>
<a href="http://sm2.sitemeter.com/stats.asp?site=sm2kc-clients" target="_top">
<img src="http://sm2.sitemeter.com/meter.asp?site=sm2kc-clients" alt="Site Meter" border="0"/></a>
</noscript>
<!-- Copyright (c)2005 Site Meter -->
<!--WEBBOT bot="HTMLMarkup" Endspan -->

</table>


</BODY>



</HTML>

