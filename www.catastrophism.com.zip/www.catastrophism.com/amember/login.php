<html>
<head>
    <title>Please login</title>
    <style>
        /* properties for entire page and text inside tables */
        body, th, td {
            background-color: ;
            color: ;
            font-family: Verdana, sans-serif;
            font-size: 9pt;
        }
        /* properties for all input elements */
        input, textarea {
            font-family: Verdana, sans-serif;
            font-size: 9pt;
        }
        /* properties for headers */
        .hdr, h1 {
            color: #707070;
            font-size: 140%;
            font-weight: bold;
            text-align: center;
        }
        /* vedit - vertical table (signup, profile edit) */
        .vedit {
            background-color: #F0F0F0;
        }
        /* vedit - usual column (right) */
        .vedit td {
            padding: 10px;
            padding-left:  15px;
            background-color: #E0E0E0;
        }
        /* vedit - header column (left) */
        .vedit th {
            padding: 10px;
            padding-right: 15px;
            text-align: right;
            background-color: #C0B9C0;
            font-weight: normal;
        }
        /* hedit - horizontal table (payments list) */
        .hedit {
            background-color: #F0F0F0;
        }
        /* hedit - usual column */
        .hedit td {
            padding: 5px;
            background-color: #E0E0E0;
            font-family: "Verdana";
            font-size: 8pt;
        }
        /* hedit - header column */
        .hedit th {
            padding: 5px;
            background-color: #C0B9C0;
        }
    </style>
</head>
<body bgcolor=white leftmargin=0 topmargin=0>

<table cellpadding=0 cellspacing=0 border=0><tr>
<td bgcolor="black" width=286 align="center"><img src="/intro/earth128.jpg" width="128" height="128" border="0" alt="" vspace=5></td>
<td width=652 bgcolor="black" align="center">
<font size="+4" color="white"><b>Catastrophism.com</b></font><br>
<table cellpadding=1 cellspacing=0 bxxxorder=1 width=540 style="border-radius: 20px 20px; -moz-border-radius: 20px;border:#888888 3px;border-style:solid;" bgcolor="white"><tr><td align="center"><font size="+0" cxxolor="white"><b>Man, Myth &amp; Mayhem in Ancient History and the Sciences</b></font></td></tr></table>
<font size="-1" color="white">Archaeology astronomy biology catastrophism chemistry cosmology geology geophysics<br> history linguistics mythology palaeontology physics psychology religion Uniformitarianism</font>
</td>
<td valign="bottom" bgcolor="black"><img src="/intro/x-corner-y.gif" width="32" height="32" border="0" alt=""></td>
</tr></table><center>
<div class=hdr>Please login | <a href="/intro/index.php">Home</a></div>
<hr>
<p><br>
<center><font color=red><b>If you are not registered yet:</b></font> <a href="http://www.catastrophism.com/amember/signup.php">Signup here</a>
<p>

<form name="login" method="post" action="/amember/login.php">

<table class="vedit" >
    <tr>
        <th>Username</th>
        <td><input type="text" name="amember_login" size="15" value="" /></td>
    </tr>
    <tr>
        <th>Password</th>
        <td><input type="password" name="amember_pass" size="15" /></td>
    </tr>
    </table>
<input type="hidden" name="login_attempt_id" value="1279464039" />
<br />

<input type="submit" value="&nbsp;&nbsp;&nbsp;Login&nbsp;&nbsp;&nbsp;" />&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="button" value="&nbsp;&nbsp;&nbsp;Back&nbsp;&nbsp;&nbsp;" onclick="history.back(-1)" />
</form>

<br />


<p><br>

<center><font color=red><b>Lost password?</b></font></center><p>
<form name="sendpass" method="post" action="http://www.catastrophism.com/amember/sendpass.php">
<table align="center" class="vedit" width="30%">
    <tr>
        <th>Enter your <b>E-Mail Address</b> or <b>Username</b></th>
        <td><input type="text" name="login" size="12" /></td>
    </tr>
</table>
<input type="submit" value="Get Password" />
</form>
</center>
<hr>
<small>&copy; <a href=http://cgi-central.net>CGI-Central.Net</a>, 2002-2003</small>
</body></html>