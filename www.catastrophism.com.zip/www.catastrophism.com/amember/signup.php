<html>
<head>
    <title>Sign-up</title>
    <style>
        /* properties for entire page and text inside tables */
        body, th, td {
            background-color: ;
            color: ;
            font-family: Verdana, sans-serif;
            font-size: 9pt;
        }
        /* properties for all input elements */
        input, textarea {
            font-family: Verdana, sans-serif;
            font-size: 9pt;
        }
        /* properties for headers */
        .hdr, h1 {
            color: #707070;
            font-size: 140%;
            font-weight: bold;
            text-align: center;
        }
        /* vedit - vertical table (signup, profile edit) */
        .vedit {
            background-color: #F0F0F0;
        }
        /* vedit - usual column (right) */
        .vedit td {
            padding: 10px;
            padding-left:  15px;
            background-color: #E0E0E0;
        }
        /* vedit - header column (left) */
        .vedit th {
            padding: 10px;
            padding-right: 15px;
            text-align: right;
            background-color: #C0B9C0;
            font-weight: normal;
        }
        /* hedit - horizontal table (payments list) */
        .hedit {
            background-color: #F0F0F0;
        }
        /* hedit - usual column */
        .hedit td {
            padding: 5px;
            background-color: #E0E0E0;
            font-family: "Verdana";
            font-size: 8pt;
        }
        /* hedit - header column */
        .hedit th {
            padding: 5px;
            background-color: #C0B9C0;
        }
    </style>
</head>
<body bgcolor=white leftmargin=0 topmargin=0>

<table cellpadding=0 cellspacing=0 border=0><tr>
<td bgcolor="black" width=286 align="center"><img src="/intro/earth128.jpg" width="128" height="128" border="0" alt="" vspace=5></td>
<td width=652 bgcolor="black" align="center">
<font size="+4" color="white"><b>Catastrophism.com</b></font><br>
<table cellpadding=1 cellspacing=0 bxxxorder=1 width=540 style="border-radius: 20px 20px; -moz-border-radius: 20px;border:#888888 3px;border-style:solid;" bgcolor="white"><tr><td align="center"><font size="+0" cxxolor="white"><b>Man, Myth &amp; Mayhem in Ancient History and the Sciences</b></font></td></tr></table>
<font size="-1" color="white">Archaeology astronomy biology catastrophism chemistry cosmology geology geophysics<br> history linguistics mythology palaeontology physics psychology religion Uniformitarianism</font>
</td>
<td valign="bottom" bgcolor="black"><img src="/intro/x-corner-y.gif" width="32" height="32" border="0" alt=""></td>
</tr></table>
<script Language="JavaScript">
<!-- hide from old browsers
function xewin(){
  features="scrollbars=yes,location=no,resizable=yes,status=no,width=500,height=150";
  myFloater = window.open('','myWindow',features);
  myFloater.close();
  myFloater = window.open('','myWindow',features);
  myFloater.location.href = "http://www.xe.com/pca/input.cgi?From=GBP";
  myFloater.focus();
}
//-->
</script>
<center>
<br>
<div class=hdr>Sign-up | <a href="/intro/index.php">Back</a></div>
<hr>
If you have signed-up before, then you should <span STYLE='color: red; background-color: yellow'><a href='/amember/login.php'>Log-in</a></span><br>to your account and Add to, or Renew, your Subscription there
<hr>
For accurate daily current conversion rates, please visit <a href="http://www.xe.com/pca/input.cgi?From=GBP" target="newwin" onClick="xewin();return false">xe.com</a><br>
As an <b>approximate</b> guide, &pound;1 = $1.80, &pound;2 = $3.60, &pound;5 = $9.00<br>&pound;10 = $18.00, &pound;20 = $36.00, &pound;50 = $90.00, &pound;75 = $135.00


<form id="signup" method="post" action="/amember/signup.php">

<table class="vedit" summary="Signup Form">
<tr valign="top">
    <th><b><font color=red>Select other Membership Types below:</font></b><p>
<ul>
<li><a href="http://www.catastrophism.com/amember/signup.php">ALL publications</a>
<li><a href="http://www.catastrophism.com/amember/signup.php?price_group=200">Only Books</a>
<li><a href="http://www.catastrophism.com/amember/signup.php?price_group=1">1 Week comparison</a>
<p>
<b>Access specific publications</b><br>
<li><a href="http://www.catastrophism.com/amember/signup.php?price_group=10">Aeon Journal</a>
<li><a href="http://www.catastrophism.com/amember/signup.php?price_group=20">Catastrophism & Ancient History</a>
<li><a href="http://www.catastrophism.com/amember/signup.php?price_group=30">Catastrophist Geology</a>
<li><a href="http://www.catastrophism.com/amember/signup.php?price_group=40">Horus</a>
<li><a href="http://www.catastrophism.com/amember/signup.php?price_group=50">Kronos</a>
<li><a href="http://www.catastrophism.com/amember/signup.php?price_group=60">Pens&eacute;e</a>
<li><a href="http://www.catastrophism.com/amember/signup.php?price_group=70">SIS Internet Digest</a>
<li><a href="http://www.catastrophism.com/amember/signup.php?price_group=80">SIS C&C Review</a>
<li><a href="http://www.catastrophism.com/amember/signup.php?price_group=100">SIS Workshop</a>
<li><a href="http://www.catastrophism.com/amember/signup.php?price_group=120">The Velikovskian</a>

</ul></th>
    <td>
    <b>Select Membership Types</b><br>48-hour access unless indicated<p>
                <input class="required" type="checkbox" id="product1" name="product_id[]" value="1"
                />
                <label for="product1"><b>Catastrophism: All Publications (24-hours)</b> (�5.00 for one day)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product2" name="product_id[]" value="2"
                />
                <label for="product2"><b>Catastrophism: All Publications (1 week)</b> (�10.00 for 7 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product3" name="product_id[]" value="3"
                />
                <label for="product3"><b>Catastrophism: All publications (1 month)</b> (�20.00 for 31 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product4" name="product_id[]" value="4"
                />
                <label for="product4"><b>Catastrophism: All publications (3 months)</b> (�40.00 for 93 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product5" name="product_id[]" value="5"
                />
                <label for="product5"><b>Catastrophism: All publications (6 months)</b> (�75.00 for 6 months)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product6" name="product_id[]" value="6"
                />
                <label for="product6"><b>Catastrophism: All publications (1 year)</b> (�100.00 for one year)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product7" name="product_id[]" value="7"
                />
                <label for="product7"><b>Aeon Journal (All Issues for 1 week)</b> (�10.00 for 7 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product12" name="product_id[]" value="12"
                />
                <label for="product12"><b>Aeon 1:1 (48 hours)</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product13" name="product_id[]" value="13"
                />
                <label for="product13"><b>Aeon 1:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product14" name="product_id[]" value="14"
                />
                <label for="product14"><b>Aeon 1:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product15" name="product_id[]" value="15"
                />
                <label for="product15"><b>Aeon 1:4</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product258" name="product_id[]" value="258"
                />
                <label for="product258"><b>Aeon 1:5</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product259" name="product_id[]" value="259"
                />
                <label for="product259"><b>Aeon 1:6</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product16" name="product_id[]" value="16"
                />
                <label for="product16"><b>Aeon 2:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product17" name="product_id[]" value="17"
                />
                <label for="product17"><b>Aeon 2:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product18" name="product_id[]" value="18"
                />
                <label for="product18"><b>Aeon 2:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product19" name="product_id[]" value="19"
                />
                <label for="product19"><b>Aeon 2:4</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product260" name="product_id[]" value="260"
                />
                <label for="product260"><b>Aeon 2:5</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product261" name="product_id[]" value="261"
                />
                <label for="product261"><b>Aeon 2:6</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product20" name="product_id[]" value="20"
                />
                <label for="product20"><b>Aeon 3:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product21" name="product_id[]" value="21"
                />
                <label for="product21"><b>Aeon 3:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product22" name="product_id[]" value="22"
                />
                <label for="product22"><b>Aeon 3:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product23" name="product_id[]" value="23"
                />
                <label for="product23"><b>Aeon 3:4</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product262" name="product_id[]" value="262"
                />
                <label for="product262"><b>Aeon 3:5</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product263" name="product_id[]" value="263"
                />
                <label for="product263"><b>Aeon 3:6</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product24" name="product_id[]" value="24"
                />
                <label for="product24"><b>Aeon 4:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product25" name="product_id[]" value="25"
                />
                <label for="product25"><b>Aeon 4:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product26" name="product_id[]" value="26"
                />
                <label for="product26"><b>Aeon 4:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product27" name="product_id[]" value="27"
                />
                <label for="product27"><b>Aeon 4:4</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product264" name="product_id[]" value="264"
                />
                <label for="product264"><b>Aeon 4:5</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product265" name="product_id[]" value="265"
                />
                <label for="product265"><b>Aeon 4:6</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product28" name="product_id[]" value="28"
                />
                <label for="product28"><b>Aeon 5:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product29" name="product_id[]" value="29"
                />
                <label for="product29"><b>Aeon 5:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product30" name="product_id[]" value="30"
                />
                <label for="product30"><b>Aeon 5:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product31" name="product_id[]" value="31"
                />
                <label for="product31"><b>Aeon 5:4</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product266" name="product_id[]" value="266"
                />
                <label for="product266"><b>Aeon 5:5</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product267" name="product_id[]" value="267"
                />
                <label for="product267"><b>Aeon 5:6</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product32" name="product_id[]" value="32"
                />
                <label for="product32"><b>Aeon 6:1</b> (�5.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product271" name="product_id[]" value="271"
                />
                <label for="product271"><b>Aeon 6:2</b> (�5.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product272" name="product_id[]" value="272"
                />
                <label for="product272"><b>Aeon 6:3</b> (�5.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product273" name="product_id[]" value="273"
                />
                <label for="product273"><b>Aeon 6:4</b> (�5.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product274" name="product_id[]" value="274"
                />
                <label for="product274"><b>Aeon 6:5</b> (�8.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product275" name="product_id[]" value="275"
                />
                <label for="product275"><b>Aeon 6:6</b> (�8.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product8" name="product_id[]" value="8"
                />
                <label for="product8"><b>Catastrophism & Ancient History (All Issues for 1 week)</b> (�10.00 for 7 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product63" name="product_id[]" value="63"
                />
                <label for="product63"><b>Catastrophism & Ancient History 1st Proceedings (1982)</b> (�5.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product64" name="product_id[]" value="64"
                />
                <label for="product64"><b>Catastrophism & Ancient History 2nd Proceedings (1983)</b> (�5.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product65" name="product_id[]" value="65"
                />
                <label for="product65"><b>Catastrophism & Ancient History 3rd Proceedings (1986)</b> (�5.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product33" name="product_id[]" value="33"
                />
                <label for="product33"><b>Catastrophism & Ancient History 1:1 (48 hours)</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product34" name="product_id[]" value="34"
                />
                <label for="product34"><b>Catastrophism & Ancient History 1:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product35" name="product_id[]" value="35"
                />
                <label for="product35"><b>Catastrophism & Ancient History 2:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product36" name="product_id[]" value="36"
                />
                <label for="product36"><b>Catastrophism & Ancient History 2:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product37" name="product_id[]" value="37"
                />
                <label for="product37"><b>Catastrophism & Ancient History 3:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product38" name="product_id[]" value="38"
                />
                <label for="product38"><b>Catastrophism & Ancient History 3:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product39" name="product_id[]" value="39"
                />
                <label for="product39"><b>Catastrophism & Ancient History 4:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product40" name="product_id[]" value="40"
                />
                <label for="product40"><b>Catastrophism & Ancient History 4:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product41" name="product_id[]" value="41"
                />
                <label for="product41"><b>Catastrophism & Ancient History 5:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product42" name="product_id[]" value="42"
                />
                <label for="product42"><b>Catastrophism & Ancient History 5:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product43" name="product_id[]" value="43"
                />
                <label for="product43"><b>Catastrophism & Ancient History 6:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product44" name="product_id[]" value="44"
                />
                <label for="product44"><b>Catastrophism & Ancient History 6:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product45" name="product_id[]" value="45"
                />
                <label for="product45"><b>Catastrophism & Ancient History 7:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product46" name="product_id[]" value="46"
                />
                <label for="product46"><b>Catastrophism & Ancient History 7:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product47" name="product_id[]" value="47"
                />
                <label for="product47"><b>Catastrophism & Ancient History 8:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product48" name="product_id[]" value="48"
                />
                <label for="product48"><b>Catastrophism & Ancient History 8:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product49" name="product_id[]" value="49"
                />
                <label for="product49"><b>Catastrophism & Ancient History 9:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product50" name="product_id[]" value="50"
                />
                <label for="product50"><b>Catastrophism & Ancient History 9:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product51" name="product_id[]" value="51"
                />
                <label for="product51"><b>Catastrophism & Ancient History 10:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product53" name="product_id[]" value="53"
                />
                <label for="product53"><b>Catastrophism & Ancient History 10:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product52" name="product_id[]" value="52"
                />
                <label for="product52"><b>Catastrophism & Ancient History 11:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product54" name="product_id[]" value="54"
                />
                <label for="product54"><b>Catastrophism & Ancient History 11:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product55" name="product_id[]" value="55"
                />
                <label for="product55"><b>Catastrophism & Ancient History 12:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product56" name="product_id[]" value="56"
                />
                <label for="product56"><b>Catastrophism & Ancient History 12:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product57" name="product_id[]" value="57"
                />
                <label for="product57"><b>Catastrophism & Ancient History 13:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product58" name="product_id[]" value="58"
                />
                <label for="product58"><b>Catastrophism & Ancient History 13:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product59" name="product_id[]" value="59"
                />
                <label for="product59"><b>Catastrophism & Ancient History 14:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product60" name="product_id[]" value="60"
                />
                <label for="product60"><b>Catastrophism & Ancient History 14:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product61" name="product_id[]" value="61"
                />
                <label for="product61"><b>Catastrophism & Ancient History 15:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product62" name="product_id[]" value="62"
                />
                <label for="product62"><b>Catastrophism & Ancient History 15:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product9" name="product_id[]" value="9"
                />
                <label for="product9"><b>Catastrophist Geology (All Issues for 1 week)</b> (�8.00 for 7 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product66" name="product_id[]" value="66"
                />
                <label for="product66"><b>Catastrophist Geology 1:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product67" name="product_id[]" value="67"
                />
                <label for="product67"><b>Catastrophist Geology 1:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product68" name="product_id[]" value="68"
                />
                <label for="product68"><b>Catastrophist Geology 2:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product69" name="product_id[]" value="69"
                />
                <label for="product69"><b>Catastrophist Geology 2:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product70" name="product_id[]" value="70"
                />
                <label for="product70"><b>Catastrophist Geology 3:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product71" name="product_id[]" value="71"
                />
                <label for="product71"><b>Catastrophist Geology 3:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product10" name="product_id[]" value="10"
                />
                <label for="product10"><b>Horus (All Issues for 1 week)</b> (�8.00 for 7 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product72" name="product_id[]" value="72"
                />
                <label for="product72"><b>Horus 1:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product73" name="product_id[]" value="73"
                />
                <label for="product73"><b>Horus 1:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product74" name="product_id[]" value="74"
                />
                <label for="product74"><b>Horus 1:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product75" name="product_id[]" value="75"
                />
                <label for="product75"><b>Horus 2:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product76" name="product_id[]" value="76"
                />
                <label for="product76"><b>Horus 2:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product77" name="product_id[]" value="77"
                />
                <label for="product77"><b>Horus 2:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product78" name="product_id[]" value="78"
                />
                <label for="product78"><b>Horus 3:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product93" name="product_id[]" value="93"
                />
                <label for="product93"><b>Kronos (All Issues for 1 week)</b> (�10.00 for 7 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product95" name="product_id[]" value="95"
                />
                <label for="product95"><b>Kronos 1:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product94" name="product_id[]" value="94"
                />
                <label for="product94"><b>Kronos 1:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product96" name="product_id[]" value="96"
                />
                <label for="product96"><b>Kronos 1:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product97" name="product_id[]" value="97"
                />
                <label for="product97"><b>Kronos 1:4</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product98" name="product_id[]" value="98"
                />
                <label for="product98"><b>Kronos 2:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product99" name="product_id[]" value="99"
                />
                <label for="product99"><b>Kronos 2:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product100" name="product_id[]" value="100"
                />
                <label for="product100"><b>Kronos 2:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product101" name="product_id[]" value="101"
                />
                <label for="product101"><b>Kronos 2:4</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product102" name="product_id[]" value="102"
                />
                <label for="product102"><b>Kronos 3:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product103" name="product_id[]" value="103"
                />
                <label for="product103"><b>Kronos 3:2</b> (�5.00 for 2 days)<br />
        <span class="small">Special issue : Velikovsky and Establishment Science</span></label><br />
                    <input class="required" type="checkbox" id="product104" name="product_id[]" value="104"
                />
                <label for="product104"><b>Kronos 3:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product105" name="product_id[]" value="105"
                />
                <label for="product105"><b>Kronos 3:4</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product106" name="product_id[]" value="106"
                />
                <label for="product106"><b>Kronos 4:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product107" name="product_id[]" value="107"
                />
                <label for="product107"><b>Kronos 4:2</b> (�5.00 for 2 days)<br />
        <span class="small">Special issue: Scientists Confront Scientists Who Confront Velikovsky</span></label><br />
                    <input class="required" type="checkbox" id="product108" name="product_id[]" value="108"
                />
                <label for="product108"><b>Kronos 4:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product109" name="product_id[]" value="109"
                />
                <label for="product109"><b>Kronos 4:4</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product110" name="product_id[]" value="110"
                />
                <label for="product110"><b>Kronos 5:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product111" name="product_id[]" value="111"
                />
                <label for="product111"><b>Kronos 5:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product112" name="product_id[]" value="112"
                />
                <label for="product112"><b>Kronos 5:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product113" name="product_id[]" value="113"
                />
                <label for="product113"><b>Kronos 5:4</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product114" name="product_id[]" value="114"
                />
                <label for="product114"><b>Kronos 6:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product115" name="product_id[]" value="115"
                />
                <label for="product115"><b>Kronos 6:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product116" name="product_id[]" value="116"
                />
                <label for="product116"><b>Kronos 6:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product117" name="product_id[]" value="117"
                />
                <label for="product117"><b>Kronos 6:4</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product118" name="product_id[]" value="118"
                />
                <label for="product118"><b>Kronos 7:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product119" name="product_id[]" value="119"
                />
                <label for="product119"><b>Kronos 7:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product120" name="product_id[]" value="120"
                />
                <label for="product120"><b>Kronos 7:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product121" name="product_id[]" value="121"
                />
                <label for="product121"><b>Kronos 7:4</b> (�5.00 for 2 days)<br />
        <span class="small">Special issue: Evolution, Extinction and Catastrophism</span></label><br />
                    <input class="required" type="checkbox" id="product122" name="product_id[]" value="122"
                />
                <label for="product122"><b>Kronos 8:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product123" name="product_id[]" value="123"
                />
                <label for="product123"><b>Kronos 8:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product124" name="product_id[]" value="124"
                />
                <label for="product124"><b>Kronos 8:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product125" name="product_id[]" value="125"
                />
                <label for="product125"><b>Kronos 8:4</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product126" name="product_id[]" value="126"
                />
                <label for="product126"><b>Kronos 9:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product127" name="product_id[]" value="127"
                />
                <label for="product127"><b>Kronos 9:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product128" name="product_id[]" value="128"
                />
                <label for="product128"><b>Kronos 9:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product129" name="product_id[]" value="129"
                />
                <label for="product129"><b>Kronos 10:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product130" name="product_id[]" value="130"
                />
                <label for="product130"><b>Kronos 10:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product131" name="product_id[]" value="131"
                />
                <label for="product131"><b>Kronos 10:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product132" name="product_id[]" value="132"
                />
                <label for="product132"><b>Kronos 11:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product133" name="product_id[]" value="133"
                />
                <label for="product133"><b>Kronos 11:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product134" name="product_id[]" value="134"
                />
                <label for="product134"><b>Kronos 11:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product135" name="product_id[]" value="135"
                />
                <label for="product135"><b>Kronos 12:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product136" name="product_id[]" value="136"
                />
                <label for="product136"><b>Kronos 12:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product137" name="product_id[]" value="137"
                />
                <label for="product137"><b>Kronos 12:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product139" name="product_id[]" value="139"
                />
                <label for="product139"><b>Pensee Immanuel Velikvosky Reconsidered (All Issues for 1 week)</b> (�10.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product140" name="product_id[]" value="140"
                />
                <label for="product140"><b>Pensee IVR 1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product141" name="product_id[]" value="141"
                />
                <label for="product141"><b>Pensee IVR 2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product142" name="product_id[]" value="142"
                />
                <label for="product142"><b>Pensee IVR 3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product143" name="product_id[]" value="143"
                />
                <label for="product143"><b>Pensee IVR 4</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product144" name="product_id[]" value="144"
                />
                <label for="product144"><b>Pensee IVR 5</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product145" name="product_id[]" value="145"
                />
                <label for="product145"><b>Pensee IVR 6</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product146" name="product_id[]" value="146"
                />
                <label for="product146"><b>Pensee IVR 7</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product147" name="product_id[]" value="147"
                />
                <label for="product147"><b>Pensee IVR 8</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product148" name="product_id[]" value="148"
                />
                <label for="product148"><b>Pensee IVR 9</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product149" name="product_id[]" value="149"
                />
                <label for="product149"><b>Pensee IVR 10</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product11" name="product_id[]" value="11"
                />
                <label for="product11"><b>SIS Internet Digest (All Issues for 1 week)</b> (�5.00 for 7 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product79" name="product_id[]" value="79"
                />
                <label for="product79"><b>SIS Internet Digest 1996:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product80" name="product_id[]" value="80"
                />
                <label for="product80"><b>SIS Internet Digest 1996:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product81" name="product_id[]" value="81"
                />
                <label for="product81"><b>SIS Internet Digest 1997:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product82" name="product_id[]" value="82"
                />
                <label for="product82"><b>SIS Internet Digest 1997:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product83" name="product_id[]" value="83"
                />
                <label for="product83"><b>SIS Internet Digest 1998:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product84" name="product_id[]" value="84"
                />
                <label for="product84"><b>SIS Internet Digest 1998:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product85" name="product_id[]" value="85"
                />
                <label for="product85"><b>SIS Internet Digest 1999:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product86" name="product_id[]" value="86"
                />
                <label for="product86"><b>SIS Internet Digest 1999:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product87" name="product_id[]" value="87"
                />
                <label for="product87"><b>SIS Internet Digest 2000:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product88" name="product_id[]" value="88"
                />
                <label for="product88"><b>SIS Internet Digest 2000:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product89" name="product_id[]" value="89"
                />
                <label for="product89"><b>SIS Internet Digest 2001:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product90" name="product_id[]" value="90"
                />
                <label for="product90"><b>SIS Internet Digest 2001:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product91" name="product_id[]" value="91"
                />
                <label for="product91"><b>SIS Internet Digest 2002:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product92" name="product_id[]" value="92"
                />
                <label for="product92"><b>SIS Internet Digest 2002:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product150" name="product_id[]" value="150"
                />
                <label for="product150"><b>SIS (C&C) Review (All Issues for 1 week)</b> (�10.00 for 7 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product151" name="product_id[]" value="151"
                />
                <label for="product151"><b>SIS Newsletter 1 & 2 (pre-Review)</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product152" name="product_id[]" value="152"
                />
                <label for="product152"><b>SIS Review 1:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product153" name="product_id[]" value="153"
                />
                <label for="product153"><b>SIS Review 1:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product154" name="product_id[]" value="154"
                />
                <label for="product154"><b>SIS Review 1:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product155" name="product_id[]" value="155"
                />
                <label for="product155"><b>SIS Review 1:4</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product156" name="product_id[]" value="156"
                />
                <label for="product156"><b>SIS Review 1:5</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product157" name="product_id[]" value="157"
                />
                <label for="product157"><b>SIS Review 2:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product158" name="product_id[]" value="158"
                />
                <label for="product158"><b>SIS Review 2:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product159" name="product_id[]" value="159"
                />
                <label for="product159"><b>SIS Review 2:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product160" name="product_id[]" value="160"
                />
                <label for="product160"><b>SIS Review 2:4</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product161" name="product_id[]" value="161"
                />
                <label for="product161"><b>SIS Review 3:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product162" name="product_id[]" value="162"
                />
                <label for="product162"><b>SIS Review 3:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product163" name="product_id[]" value="163"
                />
                <label for="product163"><b>SIS Review 3:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product164" name="product_id[]" value="164"
                />
                <label for="product164"><b>SIS Review 3:4</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product165" name="product_id[]" value="165"
                />
                <label for="product165"><b>SIS Review 4:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product166" name="product_id[]" value="166"
                />
                <label for="product166"><b>SIS Review 4:2/3</b> (�4.00 for 2 days)<br />
        <span class="small">Double issue</span></label><br />
                    <input class="required" type="checkbox" id="product167" name="product_id[]" value="167"
                />
                <label for="product167"><b>SIS Review 4:4</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product168" name="product_id[]" value="168"
                />
                <label for="product168"><b>SIS Review 5:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product169" name="product_id[]" value="169"
                />
                <label for="product169"><b>SIS Review 5:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product170" name="product_id[]" value="170"
                />
                <label for="product170"><b>SIS Review 5:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product171" name="product_id[]" value="171"
                />
                <label for="product171"><b>SIS Review 5:4</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product172" name="product_id[]" value="172"
                />
                <label for="product172"><b>SIS Review 6:1-3 Ages in Chaos? Proceedings</b> (�5.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product173" name="product_id[]" value="173"
                />
                <label for="product173"><b>SIS Review 6:4</b> (�5.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product174" name="product_id[]" value="174"
                />
                <label for="product174"><b>SIS Review 7a (there is no 7b)</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product175" name="product_id[]" value="175"
                />
                <label for="product175"><b>SIS Review 8:1 (1986) 10th Anniversary Tour Issue</b> (�5.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product176" name="product_id[]" value="176"
                />
                <label for="product176"><b>SIS C&C Review 1987</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product177" name="product_id[]" value="177"
                />
                <label for="product177"><b>SIS C&C Review 1988</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product178" name="product_id[]" value="178"
                />
                <label for="product178"><b>SIS C&C Review 1989</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product179" name="product_id[]" value="179"
                />
                <label for="product179"><b>SIS C&C Review 1990</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product180" name="product_id[]" value="180"
                />
                <label for="product180"><b>SIS C&C Review 1991</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product181" name="product_id[]" value="181"
                />
                <label for="product181"><b>SIS C&C Review 1992</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product182" name="product_id[]" value="182"
                />
                <label for="product182"><b>SIS C&C Review 1993</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product183" name="product_id[]" value="183"
                />
                <label for="product183"><b>SIS C&C Review Proceedings of the 1993 Cambridge Conference</b> (�5.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product184" name="product_id[]" value="184"
                />
                <label for="product184"><b>SIS C&C Review 1994</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product185" name="product_id[]" value="185"
                />
                <label for="product185"><b>SIS C&C Review Proceedings of The 1995 Braziers College Conference</b> (�5.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product186" name="product_id[]" value="186"
                />
                <label for="product186"><b>SIS C&C Review 1996:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product187" name="product_id[]" value="187"
                />
                <label for="product187"><b>SIS C&C Review 1996:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product188" name="product_id[]" value="188"
                />
                <label for="product188"><b>SIS C&C Review 1997:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product189" name="product_id[]" value="189"
                />
                <label for="product189"><b>SIS C&C Review 1997:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product190" name="product_id[]" value="190"
                />
                <label for="product190"><b>SIS C&C Review 1998:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product191" name="product_id[]" value="191"
                />
                <label for="product191"><b>SIS C&C Review 1998:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product192" name="product_id[]" value="192"
                />
                <label for="product192"><b>SIS C&C Review 1999:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product193" name="product_id[]" value="193"
                />
                <label for="product193"><b>SIS C&C Review 1999:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product194" name="product_id[]" value="194"
                />
                <label for="product194"><b>SIS C&C Review 2000 Proceedings of The SIS Silver Jubilee Event</b> (�5.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product195" name="product_id[]" value="195"
                />
                <label for="product195"><b>SIS C&C Review 2001:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product196" name="product_id[]" value="196"
                />
                <label for="product196"><b>SIS C&C Review 2001:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product277" name="product_id[]" value="277"
                />
                <label for="product277"><b>SIS C&C Review 2002:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product278" name="product_id[]" value="278"
                />
                <label for="product278"><b>SIS C&C Review 2002:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product279" name="product_id[]" value="279"
                />
                <label for="product279"><b>SIS C&C Review 2003 Proceedings "Ages Still in Chaos" 2002</b> (�5.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product280" name="product_id[]" value="280"
                />
                <label for="product280"><b>SIS C&C Review 2004:1 inc. Workshop 2004:2</b> (�3.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product281" name="product_id[]" value="281"
                />
                <label for="product281"><b>SIS C&C Review 2004:2 inc. Workshop 2004:3</b> (�3.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product282" name="product_id[]" value="282"
                />
                <label for="product282"><b>SIS C&C Review 2004:3 inc. Workshop 2004:4</b> (�3.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product283" name="product_id[]" value="283"
                />
                <label for="product283"><b>SIS C&C Review 2005</b> (�4.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product244" name="product_id[]" value="244"
                />
                <label for="product244"><b>SIS (C&C) Workshop (All Issues for 1 week)</b> (�10.00 for 7 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product197" name="product_id[]" value="197"
                />
                <label for="product197"><b>SIS Workshop No. 1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product198" name="product_id[]" value="198"
                />
                <label for="product198"><b>SIS Workshop No. 2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product199" name="product_id[]" value="199"
                />
                <label for="product199"><b>SIS Workshop No. 3</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product200" name="product_id[]" value="200"
                />
                <label for="product200"><b>SIS Workshop No. 4</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product201" name="product_id[]" value="201"
                />
                <label for="product201"><b>SIS Workshop No. 5</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product202" name="product_id[]" value="202"
                />
                <label for="product202"><b>SIS Workshop No. 6 (2:1)</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product203" name="product_id[]" value="203"
                />
                <label for="product203"><b>SIS Workshop 2:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product204" name="product_id[]" value="204"
                />
                <label for="product204"><b>SIS Workshop 2:3</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product205" name="product_id[]" value="205"
                />
                <label for="product205"><b>SIS Workshop 2:4</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product206" name="product_id[]" value="206"
                />
                <label for="product206"><b>SIS Workshop 3:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product207" name="product_id[]" value="207"
                />
                <label for="product207"><b>SIS Workshop 3:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product208" name="product_id[]" value="208"
                />
                <label for="product208"><b>SIS Workshop 3:3</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product209" name="product_id[]" value="209"
                />
                <label for="product209"><b>SIS Workshop 3:4</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product210" name="product_id[]" value="210"
                />
                <label for="product210"><b>SIS Workshop 4:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product211" name="product_id[]" value="211"
                />
                <label for="product211"><b>SIS Workshop 4:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product212" name="product_id[]" value="212"
                />
                <label for="product212"><b>SIS Workshop 4:3</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product213" name="product_id[]" value="213"
                />
                <label for="product213"><b>SIS Workshop 4:4</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product214" name="product_id[]" value="214"
                />
                <label for="product214"><b>SIS Workshop 5:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product215" name="product_id[]" value="215"
                />
                <label for="product215"><b>SIS Workshop 5:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product216" name="product_id[]" value="216"
                />
                <label for="product216"><b>SIS Workshop 5:3</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product217" name="product_id[]" value="217"
                />
                <label for="product217"><b>SIS Workshop 5:4</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product218" name="product_id[]" value="218"
                />
                <label for="product218"><b>SIS Workshop 6:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product219" name="product_id[]" value="219"
                />
                <label for="product219"><b>SIS Workshop 6:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product220" name="product_id[]" value="220"
                />
                <label for="product220"><b>SIS Workshop 6:3</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product221" name="product_id[]" value="221"
                />
                <label for="product221"><b>SIS C&C Workshop 1986:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product222" name="product_id[]" value="222"
                />
                <label for="product222"><b>SIS C&C Workshop 1986:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product224" name="product_id[]" value="224"
                />
                <label for="product224"><b>SIS C&C Workshop 1987:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product225" name="product_id[]" value="225"
                />
                <label for="product225"><b>SIS C&C Workshop 1987:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product226" name="product_id[]" value="226"
                />
                <label for="product226"><b>SIS C&C Workshop 1988:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product227" name="product_id[]" value="227"
                />
                <label for="product227"><b>SIS C&C Workshop 1988:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product228" name="product_id[]" value="228"
                />
                <label for="product228"><b>SIS C&C Workshop 1989:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product229" name="product_id[]" value="229"
                />
                <label for="product229"><b>SIS C&C Workshop 1989:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product230" name="product_id[]" value="230"
                />
                <label for="product230"><b>SIS C&C Workshop 1990:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product231" name="product_id[]" value="231"
                />
                <label for="product231"><b>SIS C&C Workshop 1990:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product232" name="product_id[]" value="232"
                />
                <label for="product232"><b>SIS C&C Workshop 1991:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product233" name="product_id[]" value="233"
                />
                <label for="product233"><b>SIS C&C Workshop 1991:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product234" name="product_id[]" value="234"
                />
                <label for="product234"><b>SIS C&C Workshop 1992:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product235" name="product_id[]" value="235"
                />
                <label for="product235"><b>SIS C&C Workshop 1992:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product236" name="product_id[]" value="236"
                />
                <label for="product236"><b>SIS C&C Workshop 1993:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product237" name="product_id[]" value="237"
                />
                <label for="product237"><b>SIS C&C Workshop 1993:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product238" name="product_id[]" value="238"
                />
                <label for="product238"><b>SIS C&C Workshop 1994:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product239" name="product_id[]" value="239"
                />
                <label for="product239"><b>SIS C&C Workshop 1994:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product240" name="product_id[]" value="240"
                />
                <label for="product240"><b>SIS C&C Workshop 1995:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product241" name="product_id[]" value="241"
                />
                <label for="product241"><b>SIS C&C Workshop 1995:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product242" name="product_id[]" value="242"
                />
                <label for="product242"><b>SIS C&C Workshop 1996:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product243" name="product_id[]" value="243"
                />
                <label for="product243"><b>SIS C&C Workshop 1996:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product285" name="product_id[]" value="285"
                />
                <label for="product285"><b>SIS C&C Workshop 2003:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product286" name="product_id[]" value="286"
                />
                <label for="product286"><b>SIS C&C Workshop 2003:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product287" name="product_id[]" value="287"
                />
                <label for="product287"><b>SIS C&C Workshop 2003:3</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product288" name="product_id[]" value="288"
                />
                <label for="product288"><b>SIS C&C Workshop 2004:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product289" name="product_id[]" value="289"
                />
                <label for="product289"><b>SIS C&C Workshop 2005:1</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product290" name="product_id[]" value="290"
                />
                <label for="product290"><b>SIS C&C Workshop 2005:2</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product291" name="product_id[]" value="291"
                />
                <label for="product291"><b>SIS C&C Workshop 2005:3</b> (�1.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product245" name="product_id[]" value="245"
                />
                <label for="product245"><b>The Velikovskian (All Issues for 1 week)</b> (�10.00 for 7 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product246" name="product_id[]" value="246"
                />
                <label for="product246"><b>The Velikovskian 1:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product247" name="product_id[]" value="247"
                />
                <label for="product247"><b>The Velikovskian 1:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product248" name="product_id[]" value="248"
                />
                <label for="product248"><b>The Velikovskian 1:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product249" name="product_id[]" value="249"
                />
                <label for="product249"><b>The Velikovskian 1:4</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product250" name="product_id[]" value="250"
                />
                <label for="product250"><b>The Velikovskian 2:1</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product251" name="product_id[]" value="251"
                />
                <label for="product251"><b>The Velikovskian 2:2</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product252" name="product_id[]" value="252"
                />
                <label for="product252"><b>The Velikovskian 2:3</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product253" name="product_id[]" value="253"
                />
                <label for="product253"><b>The Velikovskian 2:4</b> (�2.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product292" name="product_id[]" value="292"
                />
                <label for="product292"><b>The Velikovskian 3:1</b> (�3.00 for 3 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product293" name="product_id[]" value="293"
                />
                <label for="product293"><b>The Velikovskian 3:2</b> (�3.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product294" name="product_id[]" value="294"
                />
                <label for="product294"><b>The Velikovskian 3:3</b> (�3.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product295" name="product_id[]" value="295"
                />
                <label for="product295"><b>The Velikovskian 3:4</b> (�3.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product296" name="product_id[]" value="296"
                />
                <label for="product296"><b>The Velikovskian 4:1</b> (�4.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product297" name="product_id[]" value="297"
                />
                <label for="product297"><b>The Velikovskian 4:2</b> (�4.00 for 3 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product298" name="product_id[]" value="298"
                />
                <label for="product298"><b>The Velikovskian 4:3</b> (�4.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product299" name="product_id[]" value="299"
                />
                <label for="product299"><b>The Velikovskian 4:4</b> (�4.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product300" name="product_id[]" value="300"
                />
                <label for="product300"><b>The Velikovskian 5:1</b> (�5.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product301" name="product_id[]" value="301"
                />
                <label for="product301"><b>The Velikovskian 5:2</b> (�5.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product302" name="product_id[]" value="302"
                />
                <label for="product302"><b>The Velikovskian 5:3</b> (�5.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product303" name="product_id[]" value="303"
                />
                <label for="product303"><b>The Velikovskian 5:4</b> (�5.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product304" name="product_id[]" value="304"
                />
                <label for="product304"><b>The Velikovskian 6:1</b> (�6.00 for 2 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product256" name="product_id[]" value="256"
                />
                <label for="product256"><b>Age of Velikovsky (1 week)</b> (�10.00 for 7 days)<br />
        <span class="small">by C. J. Ransom (1976)</span></label><br />
                    <input class="required" type="checkbox" id="product305" name="product_id[]" value="305"
                />
                <label for="product305"><b>Bombarded Earth (1 week)</b> (�10.00 for 7 days)<br />
        <span class="small">by Ren� Gallant (1964)</span></label><br />
                    <input class="required" type="checkbox" id="product306" name="product_id[]" value="306"
                />
                <label for="product306"><b>Cataclysms of the Earth (1 week)</b> (�10.00 for 7 days)<br />
        <span class="small">by Hugh Auchincloss Brown (1967)</span></label><br />
                    <input class="required" type="checkbox" id="product307" name="product_id[]" value="307"
                />
                <label for="product307"><b>Catastrophism, Neocatastrophism and Evolution (1 week)</b> (�10.00 for 7 days)<br />
        <span class="small"></span></label><br />
                    <input class="required" type="checkbox" id="product254" name="product_id[]" value="254"
                />
                <label for="product254"><b>Dawn of Astronomy (1 week)</b> (�10.00 for 7 days)<br />
        <span class="small">by J. Norman Lockyer (1894)</span></label><br />
                    <input class="required" type="checkbox" id="product255" name="product_id[]" value="255"
                />
                <label for="product255"><b>Migration of Symbols (1 week)</b> (�10.00 for 7 days)<br />
        <span class="small">by Donald A. Mackenzie (1926)</span></label><br />
                    <input class="required" type="checkbox" id="product311" name="product_id[]" value="311"
                />
                <label for="product311"><b>Recollections of a Fallen Sky (1 week)</b> (�10.00 for 7 days)<br />
        <span class="small">Edited by E.R. Milton (1974)</span></label><br />
                    <input class="required" type="checkbox" id="product257" name="product_id[]" value="257"
                />
                <label for="product257"><b>Saturn Myth (1 week)</b> (�10.00 for 7 days)<br />
        <span class="small">by David N., Talbott, (1980)</span></label><br />
                    <input class="required" type="checkbox" id="product312" name="product_id[]" value="312"
                />
                <label for="product312"><b>Star Names: Their Lore and Meaning</b> (�10.00 for 7 days)<br />
        <span class="small">Formerly titled "Star-Names and Their Meanings" by Richard Hinckley Allen (1899)</span></label><br />
                    <input class="required" type="checkbox" id="product308" name="product_id[]" value="308"
                />
                <label for="product308"><b>The Celestial Ship of North (1 week)</b> (�10.00 for 7 days)<br />
        <span class="small">by E. Valentia Straiton (1927)</span></label><br />
                    <input class="required" type="checkbox" id="product309" name="product_id[]" value="309"
                />
                <label for="product309"><b>The Legends of the Jews (1 week)</b> (�10.00 for 7 days)<br />
        <span class="small">by Louis Ginzberg</span></label><br />
                    <input class="required" type="checkbox" id="product310" name="product_id[]" value="310"
                />
                <label for="product310"><b>The Night of the Gods Vols 1 & 2 (1 week)</b> (�10.00 for 7 days)<br />
        <span class="small">by John O'Neill (1893)</span></label><br />
                    <input class="required" type="checkbox" id="product314" name="product_id[]" value="314"
                />
                <label for="product314"><b>Velikovsky and his Critics (1 week)</b> (�5.00 for 7 days)<br />
        <span class="small">by Shane Mage (1978)</span></label><br />
                    <input class="required" type="checkbox" id="product315" name="product_id[]" value="315"
                />
                <label for="product315"><b>Velikovsky's Sources (6 volumes) (1 week)</b> (�10.00 for 7 days)<br />
        <span class="small">by Bob Forrest (1981)</span></label><br />
                    <input class="required" type="checkbox" id="product320" name="product_id[]" value="320"
                />
                <label for="product320"><b>Writings by Charles Ginenthal:</b> (�15.00 for 7 days)<br />
        <span class="small">� Carl Sagan & Immanuel Velikovsky (1995 )
� Stephen Jay Gould and Immanuel Velikovsky (1996)</span></label><br />
                    <input class="required" type="checkbox" id="product321" name="product_id[]" value="321"
                />
                <label for="product321"><b>Writings by William Fairfield Warren</b> (�10.00 for 7 days)<br />
        <span class="small">� Earliest Cosmologies (1909)
� Paradise Found (1885)</span></label><br />
                    <input class="required" type="checkbox" id="product317" name="product_id[]" value="317"
                />
                <label for="product317"><b>Writings of  H. S. Bellamy: (1 week)</b> (�20.00 for 7 days)<br />
        <span class="small">� Moons, Myths and Man (1936)
� Book of Revelation is History (1942)
� Built Before the Flood (1943)
� In the Beginning: God (1945)
� The Atlantis Myth (1948)
� A Life History of Our Earth (1951)</span></label><br />
                    <input class="required" type="checkbox" id="product316" name="product_id[]" value="316"
                />
                <label for="product316"><b>Writings of Comyns Beaumont: (1 week)</b> (�15.00 for 7 days)<br />
        <span class="small">� The Riddle of the Earth (1925)
� The Mysterious Comet (1932)
� The Riddle of Prehistoric Britain (1945)</span></label><br />
                    <input class="required" type="checkbox" id="product319" name="product_id[]" value="319"
                />
                <label for="product319"><b>Writings of Hugh Crosthwaite (1 week)</b> (�10.00 for 7 days)<br />
        <span class="small">� Ka (1992)
� A Fire Not Blown (1997)</span></label><br />
                    <input class="required" type="checkbox" id="product313" name="product_id[]" value="313"
                />
                <label for="product313"><b>Writings of Isaac Veil (1 week)</b> (�15.00 for 7 days)<br />
        <span class="small">includes: (a) Canopy Skies of Ancient Man (b) Celestial Records of the Orient (c) Eden's Flaming Sword (d) A Glance at Comparative Mythology (e)  Golden Age Canopy (f) The Heavens and Earth of Prehistoric Man (g) The Misread Record or The Deluge and its Cause
(h) Mythic Mountains (i) The Ring of Truth (j) The Earth's Annular System (1912 book) (k) The Vailan or Annular Theory (1892 book)</span></label><br />
                    <input class="required" type="checkbox" id="product318" name="product_id[]" value="318"
                />
                <label for="product318"><b>Writings of Melvin A. Cook</b> (�10.00 for 7 days)<br />
        <span class="small">� Prehistory and Earth Models (1966)
� Scientific Prehistory (1993)</span></label><br />
            </td>
</tr>

<tr>
    <th><b>Payment Options</b><br>Amex | MasterCard | Visa | Switch/Maesto<p>Via PayPal</th>
    <td>Note: Payment will be<ul>
<li>to Knowledge Computing
<li>in UK Pounds Sterling
<li>Converted to your local currency by your bank at the prevailing rate
</ul>
Complete the boxes below, and press Continue to register first.<br>
You'll be asked for payment when you confirm your registration.<br>
If you have a coupon code, enter it below<p>
                        <input type="hidden" id="paysys_idpaypal" name="paysys_id" value="paypal" />
        <label for="paysys_idpaypal"><b>PayPal</b>
            <span class="small">See <a href="http://www.paypal.com" target=_blank>www.paypal.com</a> for description</span></label><br /><br />
            </td>
</tr>

<tr>
    <th width="40%">Your Name *<br />
    <div class="small">Your First &amp; Last name</div></th>
    <td nowrap="nowrap"><input class="required" type="text" name="name_f" value="" size="15" />
        <input type="text" class="required" name="name_l" value="" size="15" />
    </td>
</tr>

<tr>
    <th><b>Your E-Mail Address *</b><br />
    <div class="small"><label for="id">A confirmation email will be sent</label><br />to you at this address</div></th>
    <td><input id="f_email" class="required email" type="text" name="email" value="" size="30" />
    </td>
</tr>

<tr>
    <th>Choose a Login Name (User ID) *<br />
    <div class="small">It must be 4 or more characters in length and may<br />
           only contain small letters, numbers, and<br />the underscore '_'</div></th>
    <td><input type="text" id="f_login"
    class="{required:true, rangelength:[4, 32],
        remoteUniqLogin: 'ajax.php'}"
    name="login" value="" size="15" />
    <div id="d_login"></div>
    </td>
</tr>

<tr>
    <th>Choose a Password *<br />
    <div class="small">Must be 4 or more characters</div></th>
    <td><input id="f_pass0" type="password"
    class="{required:true, rangelength:[4, 32]}"
    name="pass0" value="" size="15" />
    </td>
</tr>

<tr>
    <th>Confirm your password *<br />
    <div class="small">Enter password again</div></th>
    <td><input id="pass1" type="password" class="{equalTo: '#f_pass0'}" name="pass1" value="" size="15" />
    </td>
</tr>




<tr>
    <th colspan="2" class="headrow">COUPONS</th>
</tr>
<tr>
    <th><b>Enter coupon code</b><br />
    <div class="small">if you get any coupon code from advertising,<br /> please enter it here</div></th>
    <td><input type="text" name="coupon" id="f_coupon"
    class="{ remoteCoupon: 'ajax.php'}"
    value="" size="15" />
    </td>
</tr>
</table>
<br />
<input type="hidden" name="do_payment" value="1" />
<input type="hidden" name="price_group" value="" />
<input type="submit" value="&nbsp;&nbsp;&nbsp;Continue&nbsp;&nbsp;&nbsp;" />
</form>

<br /><br />
<p class="powered">Powered by <a href="http://www.amember.com/">aMember Pro</a> membership software</p>
</center>
<script type="text/javascript" src="http://www.catastrophism.com/amember/includes/jquery/jquery.js?smarty"></script>
<script type="text/javascript" src="http://www.catastrophism.com/amember/includes/jquery/jquery.select.js?smarty"></script>
<script type="text/javascript" src="http://www.catastrophism.com/amember/includes/jquery/jquery.metadata.min.js?smarty"></script>
<script type="text/javascript" src="http://www.catastrophism.com/amember/includes/jquery/jquery.validate.pack.js?smarty"></script>

<script type="text/javascript">

var statesCache = {};
statesCache.US = {"AL":"Alabama","AK":"Alaska","AS":"American Samoa","AZ":"Arizona","AR":"Arkansas","CA":"California","CO":"Colorado","CT":"Connecticut","DE":"Delaware","DC":"District of Columbia","FL":"Florida","GA":"Georgia","GU":"Guam","HI":"Hawaii","ID":"Idaho","IL":"Illinois","IN":"Indiana","IA":"Iowa","KS":"Kansas","KY":"Kentucky","LA":"Louisiana","ME":"Maine","MD":"Maryland","MA":"Massachusetts","MI":"Michigan","MN":"Minnesota","MS":"Mississippi","MO":"Missouri","MT":"Montana","NE":"Nebraska","NV":"Nevada","NH":"New Hampshire","NJ":"New Jersey","NM":"New Mexico","NY":"New York","NC":"North Carolina","ND":"North Dakota","MP":"Northern Mariana Islands","OH":"Ohio","OK":"Oklahoma","OR":"Oregon","PA":"Pennsylvania","PR":"Puerto Rico","RI":"Rhode Island","SC":"South Carolina","SD":"South Dakota","TN":"Tennessee","TX":"Texas","UM":"U.S. Minor Outlying Islands","UT":"Utah","VT":"Vermont","VI":"Virgin Islands of the U.S.","VA":"Virginia","WA":"Washington","WV":"West Virginia","WI":"Wisconsin","WY":"Wyoming"};
statesCache.CA = {"AB":"Alberta","BC":"British Columbia","MB":"Manitoba","NB":"New Brunswick","NL":"Newfoundland and Labrador","NT":"Northwest Territories","NS":"Nova Scotia","NU":"Nunavut","ON":"Ontario","PE":"Prince Edward Island","QC":"Quebec","SK":"Saskatchewan","YT":"Yukon Territory"};



function changeStates(obj) {

        var country = obj.options[obj.selectedIndex].value;
        var nm = (obj.name == 'cc_country') ? '#f_cc_state' : '#f_state';
        $(nm).removeOption(/.|^$/).
        addOption('', '[Select state]');
        
        if (statesCache[country]){
            $(nm).addOption(statesCache[country]).selectOptions('', true);
            onStatesLoaded();
        } else {
            onStatesLoaded();
            $(nm).attr('selectedIndex', -1);
            $(nm).ajaxAddOption("ajax.php", 
                {"do" : "get_states", "country" : country}, false, onStatesLoaded);
        }
}

//select states in drop down list
function selectStates(obj) {
        var nm = (obj.name == 'cc_country') ? '#f_cc_state' : '#f_state';
        var nmt = (obj.name == 'cc_country') ? '#t_cc_state' : '#t_state';
        var selected=$(nmt)[0].value;
        if (selected!='') {       
            tmp=nm+" > option[@value='"+selected+"']";
            $(tmp).attr("selected", "selected");
        }
}

$(document).ready(function(){
    $("#f_country, #f_cc_country").change(function(){
        changeStates(this);
    });
       
    onStatesLoaded();
    
    $("#f_country, #f_cc_country").each(function(){
        changeStates(this);
    });
});


function onStatesLoaded(){
    // this function called after completion of Ajax or after changing 
    // state list options
    // we will display text box instead of selectBox if no states found
    selObj = $("#f_state")[0];
    if (selObj){
        if (selObj.options.length <= 1){
            $("#f_state").hide().attr("disabled", true).attr('_required', false);
            $("#t_state").show().attr("disabled", false).attr('_required', true);
        } else {
            $("#f_state").show().attr("disabled", false).attr('_required', true);;
            $("#t_state").hide().attr("disabled", true).attr('_required', false);;
        }
    }
    selObj = $("#f_cc_state")[0];
    if (selObj){
        if (selObj.options.length <= 1){
            $("#f_cc_state").hide().attr("disabled", true);
            $("#t_cc_state").show().attr("disabled", false);
        } else {
            $("#f_cc_state").show().attr("disabled", false);
            $("#t_cc_state").hide().attr("disabled", true);
        }
    }  
    
    $("#f_country, #f_cc_country").each(function(){
        selectStates(this);
    });     
}
</script><script type="text/javascript">

jQuery.validator.addMethod("remoteUniqLogin", function(value, element, params) { 
  	var previous = this.previousValue(element);

  	if (!this.settings.messages[element.name] )
  		this.settings.messages[element.name] = {};
  	this.settings.messages[element.name].remoteUniqLogin = 
      	this.settings.messages[element.name].remote = 
        typeof previous.message == "function" ? previous.message(value) : previous.message;
  	
  	if ( previous.old !== value ) {
  		previous.old = value;
  		var validator = this;
  		this.startRequest(element);
  		var data = {
            'do'    : "check_uniq_login",
            'login' : $("#f_login").val(),
            'email' : $("#f_email").val(),
            'pass'  : $("#f_pass0").val()
        };
  		jQuery.ajax({
            type: "POST",
  			url: params,
  			mode: "abort",
  			port: "validate" + element.name,
  			dataType: "json",
  			data: data,
  			success: function(response) {
        		if ( !response || response.errorCode>0 ) {
    				var errors = {};
                    validator.settings.messages[element.name]['remote'] = 
                    validator.settings.messages[element.name]['remoteUniqLogin'] = 
                            response.msg;
  					errors[element.name] =  response.msg || validator.defaultMessage( element, "remoteUniqLogin" );
                    previous.message = response.msg;
                    jQuery.data(element, "previousValue", previous);
  					validator.showErrors(errors);
  				} else {
  					var submitted = validator.formSubmitted;
  					validator.prepareElement(element);
  					validator.formSubmitted = submitted;
  					validator.successList.push(element);
  					validator.showErrors();
  				}
  				previous.valid = response && (response.errorCode == 0);
  				validator.stopRequest(element, response);
  			}
  		});
  		return "pending";
  	} else if( this.pending[element.name] ) {
  		return "pending";
  	}
  	return previous.valid;
  }, "Incorect value"); 

</script><script type="text/javascript">

jQuery.validator.addMethod("remoteCoupon", function(value, element, params) { 
  	var previous = this.previousValue(element);

  	if (!this.settings.messages[element.name] )
  		this.settings.messages[element.name] = {};
  	this.settings.messages[element.name].remoteCoupon = 
        typeof previous.message == "function" ? previous.message(value) : previous.message;

    if (value == "")
        return true;
  	
  	if ( previous.old !== value ) {
  		previous.old = value;
  		var validator = this;
  		this.startRequest(element);
  		var data = {
            'do'    : "check_coupon",
            'coupon' : $("#f_coupon").val()
        };
  		jQuery.ajax({
            type: "POST",
  			url: params,
  			mode: "abort",
  			port: "validate" + element.name,
  			dataType: "json",
  			data: data,
  			success: function(response) {
        		if ( !response || response.errorCode>0 ) {
    				var errors = {};
                    validator.settings.messages[element.name]['remoteCoupon'] = 
                            response.msg;
  					errors[element.name] =  response.msg || validator.defaultMessage( element, "remoteCoupon" );
                    previous.message = response.msg;
                    jQuery.data(element, "previousValue", previous);
  					validator.showErrors(errors);
  				} else {
  					var submitted = validator.formSubmitted;
  					validator.prepareElement(element);
  					validator.formSubmitted = submitted;
  					validator.successList.push(element);
  					validator.showErrors();
  				}
  				previous.valid = response && (response.errorCode == 0);
  				validator.stopRequest(element, response);
  			}
  		});
  		return "pending";
  	} else if( this.pending[element.name] ) {
  		return "pending";
  	}
  	return previous.valid;
  }, "Incorect value"); 

</script>
<script type="text/javascript">
// TODO: coupon, uniq_login ajax check, additional fields
function checkLogin(){
    $("#signup").validate().element("#f_login");
}
function checkCoupon(){
    $("#signup").validate().element("#f_coupon");
}
$(document).ready(function(){
    var prevLogin = "";
    var prevCoupon = "";
    var timeout = null;

    $("#signup").validate({
   	onkeyup: function(element) {
   		if ( element.name in this.submitted || element == this.lastElement ) {
            if (element.id == 'f_login'){
                var l = element.value;
                if (l == prevLogin) return;
                clearTimeout(timeout);
                timeout = setTimeout(checkLogin, 1*1000);
                prevLogin = l;
            } else if (element.id == 'f_coupon'){
                var c = element.value;
                if (c == prevCoupon) return;
                clearTimeout(timeout);
                timeout = setTimeout(checkCoupon, 1*1000);
                prevCoupon = c;
            } else
       			this.element(element);
   		}
   	},
    rules: {
	    "_notexisting_": "required" // for the following comma
	
				,paysys_id: "required"
			    	
	},
  	errorPlacement: function(error, element) {
		error.appendTo( element.parent());
	}
    });
});
</script>

<hr>
<small>&copy; <a href=http://cgi-central.net>CGI-Central.Net</a>, 2002-2003</small>
</body></html>