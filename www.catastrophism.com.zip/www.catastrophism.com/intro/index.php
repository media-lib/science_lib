<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>Catastrophism: Man, Myth and Mayhem in Ancient History and the Sciences</title>

<META NAME="description" CONTENT="Catastrophism! Online archive">

<META NAME="keywords" CONTENT="catastrophism, catastrophics, catastrophes, catastrophists, interdisciplinary, mythology, folklore, archaeoastronomy, ancient history, geomagnetism, palaeontology, archaeology, biblical studies, cosmology, astronomy, geology, physics, evolution, psychology, asteroid impacts, plasma cosmology, Immanuel Velikovsky, the electric universe">

</head>

<body>
<link rel="stylesheet" href="cat.css" type="text/css">
</head>

<body bgcolor="White" leftmargin=0 topmargin=0>
<table cellpadding=0 cellspacing=0 border=0><tr>
<td bgcolor="black" width=286 align="center"><img src="earth128.jpg" width="128" height="128" border="0" alt="" vspace=5></td>
<td width=652 bgcolor="black" align="center">
<font size="+4" color="white"><b>Catastrophism.com</b></font><br>
<table cellpadding=1 cellspacing=0 bxxxorder=1 width=540 style="border-radius: 20px 20px; -moz-border-radius: 20px;border:#888888 3px;border-style:solid;" bgcolor="white"><tr><td align="center"><font size="+0" cxxolor="white"><b>Man, Myth &amp; Mayhem in Ancient History and the Sciences</b></font></td></tr></table>
<font size="-1" color="white">Archaeology astronomy biology catastrophism chemistry cosmology geology geophysics<br> history linguistics mythology palaeontology physics psychology religion Uniformitarianism</font>
</td>
<td valign="bottom" bgcolor="black"><img src="x-corner-y.gif" width="32" height="32" border="0" alt=""></td>
</tr></table>

<table align="left" cellpadding=0 cellspacing=0 border=0>

<tr valign="top"><td bgcolor="black" align="center"><font size=-1 color="white" face="courier new">Sun 18 Jul 2010</font></td>
<td valign="top"><img src="x-corner.gif" width="32" height="32" border="0" alt=""></td>
</tr>
<tr><td bgcolor="black"><font face="arial,helvetica">
<center>

<table cellpadding=10 cellspacing=5 border=0 width=276>
<tr bgcolor="#cccccc"><td><font size=-1>

<center><b><a href='index.php'>Home</a>&nbsp; | <a href='/cdrom/index.htm'>Browse</a> | <a href='/amember/signup.php'>Sign-up</a></b></center>





<p>
<form method="GET" action="search.cgi">
<hr noshade>
<center><b>Search All</b> | <a href="?f=faq">FAQ</a><br>
<input type="text" name="zoom_query" size="20" value="">
<input type="submit" value="Search">
<input type=hidden name="zoom_per_page" value=25><br>
<input type="hidden" name="zoom_and" value="1">
Where:<br><select name='zoom_cat[]'><option value="-1">All</option><option value="0">Aeon Journal $</option><option value="1">Catastrophism & Ancient History $</option><option value="2">Catastrophism Geology $</option><option value="3">Horus $</option><option value="4">SIS Internet Digest $</option><option value="5">Kronos $</option><option value="6">Pens&eacute;e</option><option value="7">SIS C&C Review $</option><option value="8">The Velikovskian $</option><option value="9">SIS C&C Workshop $</option><option value="10">The Age of Velikovsky</option><option value="11">Mythopedia Website</option><option value="12">Quantavolution Website</option><option value="13">Dawn of Astronomy (Book)</option><option value="14">Migration of Symbols (Book)</option><option value="15">The Saturn Myth</option><option value="16">Science Frontiers Website</option><option value="17">Maverick Science Website</option><option value="18">Alternative Science Website</option><option value="19">Thoth Website</option><option value="20">Velikovsky Archive Website</option><option value="21">Thunderbolts Website</option><option value="22">Books</option><option value="23">Articles</option><option value="24">Talk transcripts</option><option value="25">Uncategorised</option></select>&nbsp;&nbsp;
</form>
<hr noshade>

<b>Suggested Subjects</b><br>
<a href="search.cgi?zoom_query=archaeolog*">archaeology</a> &#149;
<a href="search.cgi?zoom_query=astronom*">astronomy</a> &#149;
<a href="search.cgi?zoom_query=biolog*">biology</a> &#149;
<a href="search.cgi?zoom_query=Catastroph*">catastrophism</a> &#149;
<a href="search.cgi?zoom_query=geolog*">geology</a> &#149;
<a href="search.cgi?zoom_query=chemi*">chemistry</a> &#149;
<a href="search.cgi?zoom_query=cosmology">cosmology</a> &#149;
<a href="search.cgi?zoom_query=geophysic*">geophysics</a> &#149;
<a href="search.cgi?zoom_query=histor*">history</a> &#149;
<a href="search.cgi?zoom_query=physics*">physics</a> &#149;
<a href="search.cgi?zoom_query=linguistics">linguistics</a> &#149;
<a href="search.cgi?zoom_query=myth*">mythology</a> &#149;
<a href="search.cgi?zoom_query=palaeontolog*">palaeontology</a> &#149;
<a href="search.cgi?zoom_query=psycholog*">psychology</a> &#149;
<a href="search.cgi?zoom_query=religio*">religion</a> &#149;
<a href="search.cgi?zoom_query=Uniformitarianism">uniformitarianism</a> &#149;
<a href="search.cgi?zoom_query=etymolog*">etymology</a>
</p>

<b>Suggested Cultures</b><br>
<a href="search.cgi?zoom_query=Egyptian?">Egyptian</a> &#149;
<a href="search.cgi?zoom_query=Greek?">Greek</a> &#149;
<a href="search.cgi?zoom_query=syrian?">Syrians</a> &#149;
<a href="search.cgi?zoom_query=Roman">Roman</a> &#149;
<a href="search.cgi?zoom_query=aborigin*">Aboriginal</a> &#149;
<a href="search.cgi?zoom_query=babylonian">Babylonian</a> &#149;
<a href="search.cgi?zoom_query=olmec?">Olmec</a> &#149;
<a href="search.cgi?zoom_query=assyrian">Assyrian</a> &#149;
<a href="search.cgi?zoom_query=persian">Persian</a> &#149;
<a href="search.cgi?zoom_query=Chinese">Chinese</a> &#149;
<a href="search.cgi?zoom_query=Japanese">Japanese</a> &#149;
<a href="search.cgi?zoom_query=near%20east*">Near East</a>
</p>

<b>Suggested keywords</b><br>
<a href="search.cgi?zoom_query=dating">dating</a> &#149;
<a href="search.cgi?zoom_query=spiral">spiral</a> &#149;
<a href="search.cgi?zoom_query=ram*ses">rameses</a> &#149;
<a href="search.cgi?zoom_query=dragon">dragon</a> &#149;
<a href="search.cgi?zoom_query=pyramid?">pyramid</a> &#149;
<a href="search.cgi?zoom_query=bizarre">bizarre</a> &#149;
<a href="search.cgi?zoom_query=plasma">plasma</a> &#149;
<a href="search.cgi?zoom_query=anomal*">anomaly</a> &#149;
<a href="search.cgi?zoom_query=big%20bang">big bang</a> &#149;
<a href="search.cgi?zoom_query=stonehenge">Stonehenge</a> &#149;
<a href="search.cgi?zoom_query=kronos">kronos</a> &#149;
<a href="search.cgi?zoom_query=evolution">evolution</a> &#149;
<a href="search.cgi?zoom_query=bible">bible</a> &#149;
<a href="search.cgi?zoom_query=cuvier">cuvier</a> &#149;
<a href="search.cgi?zoom_query=petroglyph?">petroglyphs</a> &#149;
<a href="search.cgi?zoom_query=scar">scar</a> &#149;
<a href="search.cgi?zoom_query=Einstein">Einstein</a> &#149;
<a href="search.cgi?zoom_query=red%20shift">red shift</a> &#149;
<a href="search.cgi?zoom_query=strange">strange</a> &#149;
<a href="search.cgi?zoom_query=earthquake?">earthquake</a> &#149;
<a href="search.cgi?zoom_query=trauma">trauma</a> &#149;
<a href="search.cgi?zoom_query=moses">Moses</a> &#149;
<a href="search.cgi?zoom_query=destruction">destruction</a> &#149;
<a href="search.cgi?zoom_query=hapgood">Hapgood</a> &#149;
<a href="search.cgi?zoom_query=saturn">Saturn</a> &#149;
<a href="search.cgi?zoom_query=Deluge">Deluge</a> &#149;
<a href="search.cgi?zoom_query=sacred">sacred</a> &#149;
<a href="search.cgi?zoom_query=seven">seven</a> &#149;
<a href="search.cgi?zoom_query=birkeland">Birkeland</a> &#149;
<a href="search.cgi?zoom_query=amarna">Amarna</a> &#149;
<a href="search.cgi?zoom_query=folklore">folklore</a> &#149;
<a href="search.cgi?zoom_query=shakespeare">shakespeare</a> &#149;
<a href="search.cgi?zoom_query=Genesis">Genesis</a> &#149;
<a href="search.cgi?zoom_query=glass">glass</a> &#149;
<a href="search.cgi?zoom_query=origins">origins</a> &#149;
<a href="search.cgi?zoom_query=light">light</a> &#149;
<a href="search.cgi?zoom_query=thunderbolt?">thunderbolt</a> &#149;
<a href="search.cgi?zoom_query=swastika">swastika</a> &#149;
<a href="search.cgi?zoom_query=mayan">Mayan</a> &#149;
<a href="search.cgi?zoom_query=calendar?">calendar</a> &#149;
<a href="search.cgi?zoom_query=electric">electric</a> &#149;
<a href="search.cgi?zoom_query=koran">koran</a> &#149;
<a href="search.cgi?zoom_query=dendrochronolog*">dendrochronology</a> &#149;
<a href="search.cgi?zoom_query=dinosaur?">dinosaurs</a> &#149;
<a href="search.cgi?zoom_query=gravity">gravity</a> &#149;
<a href="search.cgi?zoom_query=chronolog*">chronology</a> &#149;
<a href="search.cgi?zoom_query=stratigraph*">stratigraphical</a> &#149;
<a href="search.cgi?zoom_query=column*">columns</a> &#149;
<a href="search.cgi?zoom_query=sun">sun</a> &#149;
<a href="search.cgi?zoom_query=tanis">tanis</a> &#149;
<a href="search.cgi?zoom_query=santorini">santorini</a> &#149;
<a href="search.cgi?zoom_query=mammoth?">mammoths</a> &#149;
<a href="search.cgi?zoom_query=moon">moon</a> &#149;
<a href="search.cgi?zoom_query=*male">male/female</a> &#149;
<a href="search.cgi?zoom_query=tutankhamun">tutankhamun</a> &#149;
<a href="search.cgi?zoom_query=ankh">ankh</a> &#149;
<a href="search.cgi?zoom_query=map">map</a> &#149;
<a href="search.cgi?zoom_query=polar">polar</a> &#149;
<a href="search.cgi?zoom_query=megalith*">megalithic</a> &#149;
<a href="search.cgi?zoom_query=sun*dial">sundial</a> &#149;
<a href="search.cgi?zoom_query=homer">Homer</a> &#149;
<a href="search.cgi?zoom_query=tradition">tradition</a> &#149;
<a href="search.cgi?zoom_query=sothic">Sothic</a> &#149;
<a href="search.cgi?zoom_query=comet">comet</a> &#149;
<a href="search.cgi?zoom_query=writing">writing</a> &#149;
<a href="search.cgi?zoom_query=extinct*">extinction</a> &#149;
<a href="search.cgi?zoom_query=celestial">celestial</a> &#149;
<a href="search.cgi?zoom_query=prehistor*">prehistoric</a> &#149;
<a href="search.cgi?zoom_query=Venus">Venus</a> &#149;
<a href="search.cgi?zoom_query=horns">horns</a> &#149;
<a href="search.cgi?zoom_query=radiocarbon">radiocarbon</a> &#149;
<a href="search.cgi?zoom_query=rock%20art">rock art</a> &#149;
<a href="search.cgi?zoom_query=indian">indian</a> &#149;
<a href="search.cgi?zoom_query=meteor">meteor</a> &#149;
<a href="search.cgi?zoom_query=aurora">aurora</a> &#149;
<a href="search.cgi?zoom_query=circle">circle</a> &#149;
<a href="search.cgi?zoom_query=cross">cross</a> &#149;
<a href="search.cgi?zoom_query=Velikovsky">Velikovsky</a> &#149;
<a href="search.cgi?zoom_query=darwin">Darwin</a> &#149;
<a href="search.cgi?zoom_query=Lyell">Lyell</a>
</td></tr>
</table>
<p>

<table cellpadding=0 cellspacing=0 width=256><tr><td align=center><font color=yellow size=-1>
NEW! Must Read!<br>

<a href="http://gallery.bcentral.com/GID4907389P5341295-Books/The-Electric-Sky.aspx"><img src="electric-sky.jpg" width="192" height="251" border="1" alt=""><br>
<b><font color=cyan>The Electric Sky</font></b></a> by<br>
Donald E. Scott<br>
<span style="font-size:13";>How Plasma Cosmology and the Electric Sun theories challenge the Big Bang model</span>
<p>


<a href="http://www.kronia.com/godstar.html"><img src="god-star-192.gif" width="192" height="300" border="0" alt=""><br>
"<b><font color=cyan>God Star</font></b></a>" by<br>
Dwardu Cardona<br>
<span style="font-size:13";>which sets out to show that the sky which ancient man saw, was enitirely differnt from the one we see now.</span>
<p>

<a href="http://www.thunderbolts.info/resources.htm"><img src="thunderbolts.gif" width="192" height="248" border="1" alt=""><br>
<font color=cyan>Thunderbolts of the Gods</font></a>
<p>
The new Monograph by<br>
David Talbott and Wallace Thornhill
</td></tr></table>	




<p>
<table bgcolor="lightyellow"><tr><td>
<center>
<b>Other Good Web Sites</b>
<p><font size=-1>
<a href="http://www.sis-group.org.uk">Society for Interdisciplinary Studies</a><br>
<a href="http://www.velikovsky.info">The Velikovsky Encyclopedia</a><br>
<a href="http://www.electric-universe.info">The Electric Universe</a><br>
<a href="http://www.thunderbolts.info">Thunderbolts</a><br>
<a href="http://www.plasma-universe.com">Plasma Universe</a><br>
<a href="http://www.plasmacosmology.net">Plasma Cosmology</a><br>
<a href="http://www.science-frontiers.com">Science Frontiers</a><br>
<a href="http://www.catastrophism.com/intro/index.php?f=pubs">Indexed Web sites</a><br>
<a href="http://www.lobster-magazine.co.uk">Lobster magazine</a><br>


</td></tr></table>
<p>
<p>
<font color="lightyellow"><b>&copy; 2001-2004 Catastrophism.com</b></font><br>
<font size="-1">ISBN 0-9539862-1-7<br>v1.2</font><br>

</center>

<P><br><P>
</td></tr></table>



<table cellpadding=1 cellspacing=0 border=0 width=520><tr class='smaller'><td align='left'><span STYLE='color: red; background-color: yellow'><a href='/amember/signup.php?price_group=1'>Sign-up</a> | <a href='/amember/login.php'>Log-in</a></span></td></tr></table>



<p><br>
<p>



<b>Introduction</b>  | <a href="index.php?f=pubs">Publications</a> | <a href="?f=affs">Affiliates</a> | <a href="index.php?f=more">More</a></font><br>
<p><br>

<table cellpadding=0 cellspacing=0 width=522 class="smaller"><tr><td>

<table cellpadding=2 cellspacing=0 border=1 bgcolor="#eeeeee"><tr><td><font size=-1>
How does this archive related to <b>Ancient History?</b><br>
Read John Crowe's article, <i><a href="http://www.knowledge.co.uk/sis/ancient.htm" target="newwin">The Revision of Ancient History - A Perspective</a></i>
</td></tr></table>
<p>
Catastrophes are evident throughout our Solar System and Earth history. Comets and asteroids are usually thought to be the cause, but recent evidence suggests that cosmic plasma plays a crucial role.
<p>
99.9% of the universe is plasma (or ionized gas), that can carry electric currents whose forces are a trillion, trillion, trillion times stronger than gravity.
<p>


<table cellpadding=0 cellspacing=0 align="center"><tr class="smaller"><td width=256>
<img src="sl9-jupiter-tirgo.jpg" width="256" height="184" border="0" alt=""><br>
<font size="-1">Shoemaker-Levy 9 slams into Jupiter in 1994 &nbsp; Image: <a href="http://www.arcetri.astro.it/irlab/tirgo/">TIRGO</a></font></td><td width=20></td><td>
<img src="eye-of-horus.jpg" width="244" height="184" border="2" alt=""><br>
<font size="-1">The Eye of Horus (Wedjat eye).<br>A catastrophic symbol?</font> <font size=-2>[<a href="http://bazaarinegypt.com/catalog/product_info.php/products_id/407">Source</a>]</font>
</td></tr></table>
<p>


Ancient history features common themes, such as those of creation, destruction and cosmic imagery, such as dragons and thunderbolt-wielding gods. Craters scar many moons and the asteroid belts suggests the remains of a larger body.
<p>
<table cellpadding=0 cellspacing=0 align="center"><tr class="smaller"><td width=256>
<img src="celestial-dragon.jpg" width="256" height="256" border="2" alt=""><br>
<font size="-1">Celestial Dragon. <a href="http://www.junecolburn.com/mySearchResult.cfm?&productID=20&display=detail&categoryID=9&name=APPLIQU%C3%89%20&filterFor=dragon">June Coburn Designs</a>
</font></td><td width=20></td><td>
<img src="v838-monocerotis.jpg" width="256" height="256" border="2" alt=""><br>
<font size="-1"><a href="http://www.esa.int/export/esaSC/Pr_3_2004_h_en.html">Nebula V838 Monocerotis</a> Image: NASA</font>
</td></tr></table>
<p>
The Age of the Dinosaurs ended abruptly. Historic World Ages come and go, and civilizations rise meteorically and fall like stones from the sky.
<p>

<center>What made man build megalithic monuments around the world?</center>
<table cellpadding=0 cellspacing=0 align="center"><tr class="smaller" align="center"><td width=256>
<img src="pyramids.jpg" width="289" height="167" border="2" alt=""><br>
<font size="-1">The Pyramids at Giza</font>
</font></td><td width=20></td><td>
<img src="stonehenge-constable.jpg" width="256" height="167" border="2" alt=""><br>
<font size="-1">Constable's 1836 Stonehenge painting
</td></tr></table>

<p>

But have there been catastrophic events in mankind's more recent past? Does the wrath of the gods in ancient records symbolize earlier catastrophes? Does archaeology show significant disturbances around 2300BC? Does astronomy support catastrophism in only the early development of the Solar System, or much more recently?
<p>
<table cellpadding=0 cellspacing=0 align="center"><tr class="smaller"><td width=256>
<img src="captured-lightning.jpg" width="256" height="298" border="2" alt=""><br>
<font size="-1">"<a href="http://205.243.100.155">Captured Lightning</a>" Lichtenberg figure
</font></td><td width=20></td><td>
<img src="grand-canyon.jpg" width="256" height="298" border="2" alt=""><br>
<font size="-1">Grand Canyon satellite image</font>
</td></tr></table>

<p>
Cosmically-induced global catastrophes should be a running theme through the disciplines. Hence, this work is interdisciplinary in its very nature. And if disciplines conflict in their interpretation, does the interpretation of the evidence or the discipline require revision?
<p>
<table cellpadding=5 cellspacing=0 border=1 bgcolor="ivory" align="center"><tr><td align="center">
Did the ancients see images like these in the sky?
<p>
<table cellpadding=0 cellspacing=0 align="center" width=520><tr><td align="center">
<img src="plasma-squatting-man.jpg" width="173" height="192" border="2" alt="" hspace=5>
<img src="plasma-centipede.jpg" width="45" height="192" border="2" alt="" hspace=10>
<img src="plasma-owl-eyes.jpg" width="213" height="192" border="2" alt="" hspace=5></tr>
<tr align="center"><td><font size="-1">High-current plasma discharge sketches, like those seen in the lab,</font><br><font size="-2">After Anthony L. Peratt, IEEE Transactions on Plasma Science, Dec 1993:<br>
<a href="http://ieeexplore.ieee.org/xpl/abs_free.jsp?arNumber=1265340">Characteristics for the Occurrence of a High-Current, Z-Pinch Aurora as Recorded in Antiquity</a>, </font></td></tr>
</table>
<p>
<table cellpadding=0 cellspacing=0 align="center" width=520><tr><td align="center">
<img src="rock-art-squatters.gif" width="173" height="192" border="2" alt="" hspace="5">
<img src="rock-art-centipede.gif" width="70" height="192" border="2" alt="" hspace="5">
<img src="owl-eyes-hat.jpg" width="213" height="192" border="2" alt="" hspace="5">
</tr>
<tr align="center"><td><font size="-1">1. Middle Eastern Rock art  2. US Petroglyph 3. Easter Island hat pattern</font></td></tr>
</table>

</td></tr></table>

<p>
This work is a compilation of thousands of articles, books and Web sites, covering a wide range of viewpoints. Some are quite convincing, some speculative, and others apparently preposterous. You decide.
</td></tr></table>
<p>
<hr noshade>

</td></tr></table>
<!--WEBBOT bot="HTMLMarkup" startspan ALT="Site Meter" -->
<script type="text/javascript" language="JavaScript">var site="s11catonline"</script>
<script type="text/javascript" language="JavaScript1.2" src="http://s11.sitemeter.com/js/counter.js?site=s11catonline">
</script>
<noscript>
<a href="http://s11.sitemeter.com/stats.asp?site=s11catonline" target="_top">
<img src="http://s11.sitemeter.com/meter.asp?site=s11catonline" alt="Site Meter" border="0"/></a>
</noscript>
<!-- Copyright (c)2002 Site Meter -->
<!--WEBBOT bot="HTMLMarkup" Endspan -->

</body>
</html>

